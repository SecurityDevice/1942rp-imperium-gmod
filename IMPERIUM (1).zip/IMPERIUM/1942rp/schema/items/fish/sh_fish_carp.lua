--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/fish/sh_fish_carp.lua
Size: 125 B

]===]
ITEM.name = "Carp"
ITEM.model = "models/tsbb/fishes/carp.mdl"
ITEM.rarity = 15
ITEM.price = 380
ITEM.category = "Fishing"