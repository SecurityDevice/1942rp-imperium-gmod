--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/base/sh_ents.lua
Size: 579 B

]===]
ITEM.name = "Entity Dropper"
ITEM.desc = "Drops an Entity. You probably shouldnt be seeing this. tell a developer please."
ITEM.model = "models/weapons/w_package.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.entdrop = ""
ITEM.functions.Use = {
	name = "Use",
	icon = "icon16/cursor.png",
	onRun = function(item, player, client)

			item.player:EmitSound( "physics/flesh/flesh_bloody_break.wav", 75, 200 )
				
				local ent = ents.Create( item.entdrop )
				ent:SetPos(item.player:EyePos() + ( item.player:GetAimVector() * 50))
				ent:Spawn()

		return true
	end
}