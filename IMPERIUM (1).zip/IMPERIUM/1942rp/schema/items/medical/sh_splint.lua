--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/medical/sh_splint.lua
Size: 3883 B

]===]
ITEM.name = "Splint"
ITEM.model = "models/props_junk/wood_crate001a_chunk05.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.healAmount = 20
ITEM.healSeconds = 7
ITEM.price = 5
ITEM.desc = "A crude splint."
ITEM.uniqueID = "splint"
--ITEM.permit = "permit_med"

ITEM.iconCam = {
    pos = Vector(0, 0, 200),
    ang = Angle(90, 0, 90),
    fov = 20,
}

local SplintSelfMessages = {
    "carefully starts to apply a splint, bracing his injured leg.",
    "is meticulously wrapping a splint around his injured leg.",
    "sets about bracing his injured leg with a splint.",
    "starts the careful task of applying a splint to his damaged leg.",
    "begins securing a splint to his injured leg."
}

ITEM.functions.Use = {
    name = "Use",
	tip = "Apply the splint to yourself.",
	icon = "icon16/cog.png",
    onRun = function(item)
        local client = item.player
        if client:GetNWBool("legInjured", true) then
            client:notify("You start stabilizing your injured leg.")
            client:Say("/me " .. table.Random(SplintSelfMessages) )
            timer.Simple(item.healSeconds, function()
                if IsValid(client) and client:GetNWBool("legInjured", true) then
                    client:notify("You successfully stabilized your injured leg.")
                    client:SetNWBool("legInjured", false)
                    client:SetRunSpeed(235)
                    item:remove()
                end
            end)
            return true -- It should return true here, meaning that we successfully used the splint
        else
            client:notify("You have no use in this splint.")
            return false
        end
    end,
}


local SplintAdministerMessages = {
    "begins to expertly brace %s's injured leg with a splint.",
    "starts to skillfully secure a splint to %s's damaged leg.",
    "applies a splint on %s's wounded leg.",
    "begins to delicately fasten a splint around %s's injured leg."
}

ITEM.functions.Administer = {
    name = "Administer", 
	tip = "Apply the splint to another player.", 
	icon = "icon16/arrow_up.png", 
    onRun = function(item)
        local client = item.player
        local data = {
            start = client:GetShootPos(),
            endpos = client:GetShootPos() + client:GetAimVector() * 96,
            filter = client
        }
        local trace = util.TraceLine(data)
        local target = trace.Entity

        if IsValid(target) and target:IsPlayer() and target:GetPos():DistToSqr(client:GetPos()) <= 90000 then
            if target:GetNWBool("legInjured", false) then
                target:notify(client:Name() .. " starts stabilizing your injured leg.")
                client:notify("You start stabilizing " .. target:Name() .. "'s injured leg.")
                client:Say("/me" .. string.format(table.Random(SplintAdministerMessages), target:Nick()))

                timer.Simple(item.healSeconds, function()
                    if IsValid(target) and target:GetNWBool("legInjured", false) then
                        target:notify(client:Name() .. " successfully stabilized your injured leg.")
                        client:notify("You successfully stabilized " .. target:Name() .. "'s injured leg.")
                        target:SetNWBool("legInjured", false)
                        target:SetRunSpeed(235)
                        item:remove()
                        return true -- Remove the item from the player's inventory
                    end
                end)
            else
                client:notify(target:Name() .. "'s leg is not injured.")
            end
        else
            client:notify("You must be looking at another player.")
        end

        return false -- Prevent the item from being removed if there is no valid target
    end,
}


