--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/medical/sh_firstaidkit.lua
Size: 4562 B

]===]
ITEM.name = "First Aid Kit"
ITEM.model = "models/wick/cod1/misc/wick_medkit_large.mdl"
ITEM.width = 2
ITEM.height = 1
ITEM.healSeconds = 5
ITEM.price = 50
ITEM.desc = "A standard medical kit used to apply first aid."
ITEM.uniqueID = "firstaidkit"

ITEM.iconCam = {
	pos = Vector(10, 0, 200),
	ang = Angle(90, 30, 40),
	fov = 40,
}

local FirstAidSelfMessages = {
	"meticulously cleans their wounds before bandaging them with supplies in their first aid kit.",
	"begins to carefully dress their wounds using the materials found in their first aid kit.",
	"is methodically applying antiseptic to their wounds before bandaging them.",
	"opens the first aid kit, preparing to tend to their injuries.",
	"reaches for their first aid kit, preparing to attend to their injuries.",
	"quietly works on their injuries, using the resources from the first aid kit.",
	"with a grimace, starts treating their wounds using the contents of a first aid kit.",
	"grimly starts to disinfect their wounds, before bandaging them tightly.",
	"focuses on their wounds, applying dressings and bandages with deliberate care.",
	"begins the painstaking process of stitching up their wounds with a first aid kit.",
	"breathes deeply, readying themselves to treat their injuries with the first aid kit."
}


ITEM.functions.Use = {
    name = "Use",
	tip = "Heal yourself.",
	icon = "icon16/cog.png",
    onRun = function(item)
        local client = item.player
        if client:getChar() and client:Health() < 100 then
            client:notify("You dig into the first aid kit...")
            client:Say("/me " .. table.Random(FirstAidSelfMessages) )
            timer.Simple(item.healSeconds, function()
                if IsValid(client) then
                    client:notify("You dressed up your injuries.")
                    client:SetHealth(100)
                    item:remove()
                end
            end)
            return true -- It should return true here, meaning that we successfully used the splint
        else
            client:notify("You have no use in thisdsasd first aid kit.")
            return false
        end
    end,
}


local KitAdministerMessages = {
    "begins to dress %s's wounds with bandages from a first aid kit.",
    "uses a first aid kit to gently cleanse and bandage %s's wounds.",
    "uses a first aid kit to tend to %s's wounds.",
    "begins to carefully tend to %s's injuries using the contents of a first aid kit.",
    "opens up a first aid kit, preparing to administer medical care to %s.",
    "skillfully uses a first aid kit to treat %s's injuries.",
    "carefully applies dressings and bandages to %s's wounds using a first aid kit.",
    "works efficiently to treat %s's injuries with the items found in a first aid kit."
}


ITEM.functions.Administer = {
    name = "Administer", 
	tip = "Heal another player.", 
	icon = "icon16/arrow_up.png", 
    onRun = function(item)
        local client = item.player
        local data = {
            start = client:GetShootPos(),
            endpos = client:GetShootPos() + client:GetAimVector() * 96,
            filter = client
        }
        local trace = util.TraceLine(data)
        local target = trace.Entity

        if IsValid(target) and target:IsPlayer() and target:GetPos():DistToSqr(client:GetPos()) <= 90000 then
            if target:Health()<100 then
                target:notify(client:Name() .. " tends to your your injuries.")
                client:notify("You start tending to " .. target:Name() .. "'s injuries.")
                client:Say("/me " .. string.format(table.Random(KitAdministerMessages), target:Nick()))

                timer.Simple(item.healSeconds, function()
                    if IsValid(target) then
                        target:notify(client:Name() .. " cleared you of all injuries.")
                        client:notify("You successfully stabilized " .. target:Name() .. "'s condition.")
                        target:SetHealth(100)
                        item:remove()
                        return true -- Remove the item from the player's inventory
                    end
                end)
            else
                client:notify(target:Name() .. " is not in need of medical attention.")
            end
        else
            client:notify("You must be looking at another player.")
        end

        return false -- Prevent the item from being removed if there is no valid target
    end,
}


