ITEM.name = "M1918a2 BAR"

ITEM.desc = "American made BAR-Rifle"

ITEM.category = "Weapons"

ITEM.model = "models/khrcw2/doipack/w_bar.mdl"

ITEM.class = "doi_atow_m1918a2"

ITEM.width = 3

ITEM.height = 2

ITEM.isWeapon = true

ITEM.weaponCategory = "primary"

HOLSTER_DRAWINFO["doi_atow_m1918a2"] = {
    pos = Vector(3, 10, 3),
    ang = Angle(170, -10, 180),
    bone = "ValveBiped.Bip01_Spine",
    model = "models/khrcw2/doipack/w_bar.mdl"
}