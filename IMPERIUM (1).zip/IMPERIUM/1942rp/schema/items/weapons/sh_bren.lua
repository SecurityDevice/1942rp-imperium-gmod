ITEM.name = "Bren MKII"

ITEM.desc = "An British Machine Gun."

ITEM.category = "Weapons"

ITEM.model = "models/khrcw2/doipack/w_bren.mdl"

ITEM.class = "doi_atow_bren"

ITEM.width = 3

ITEM.height = 2

ITEM.isWeapon = true

ITEM.weaponCategory = "primary"

HOLSTER_DRAWINFO["doi_atow_bren"] = {
    pos = Vector(3, 10, 3),
    ang = Angle(170, -10, 180),
    bone = "ValveBiped.Bip01_Spine",
    model = "models/khrcw2/doipack/w_bren.mdl"
}