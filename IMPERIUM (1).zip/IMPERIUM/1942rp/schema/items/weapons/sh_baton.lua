ITEM.name = "Polizei Baton"
ITEM.desc = "A metal stick issued to police forces for crowd control."
ITEM.model = "models/weapons/w_gamma_baton.mdl"
ITEM.class = "weapon_baton"
ITEM.weaponCategory = "primary"
ITEM.uniqueID = "baton"
ITEM.width = 2
ITEM.height = 1
ITEM.price = 500
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}
ITEM.flag = "v"
ITEM.category = "Black Market"