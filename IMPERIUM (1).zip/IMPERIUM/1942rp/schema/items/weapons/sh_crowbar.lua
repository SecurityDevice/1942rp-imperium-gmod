ITEM.name = "Crowbar"
ITEM.desc = "Break down a door's hinges."
ITEM.model = "models/weapons/w_crowbar.mdl"
ITEM.class = "nut_crowbar"
ITEM.weaponCategory = "primary"
ITEM.uniqueID = "crowbar"
ITEM.width = 2
ITEM.height = 1
ITEM.price = 10000

ITEM.flag = "v"
ITEM.category = "Black Market"