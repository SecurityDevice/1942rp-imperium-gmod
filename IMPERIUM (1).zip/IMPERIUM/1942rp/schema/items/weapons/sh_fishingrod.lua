ITEM.name = "Fishing Rod"
ITEM.desc = "A tool primarily used for catching fish."
--ITEM.exRender = true
ITEM.model = "models/pg_props/pg_weapons/pg_fishing_rod_w.mdl"
ITEM.width = 1
ITEM.height = 1
--[[ITEM.iconCam = {
	pos = Vector(445.18963623047, 376.15814208984, 289.1086730957),
	ang = Angle(25, 220, 0),
	fov = 2,
}--]]
ITEM.class = "fishing_rod"
ITEM.category = "Fishing"
ITEM.price = 20
ITEM.noBusiness = true
ITEM.weaponCategory = "melee"