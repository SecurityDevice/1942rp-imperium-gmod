--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/sh_cigpack.lua
Size: 804 B

]===]
ITEM.name = "Cigarette Pack"
ITEM.desc = "A pack of cigarettes."
ITEM.model = "models/boxopencigshib.mdl"
ITEM.price = 100
ITEM.PackNum = 10
ITEM.category = "Drugs"

ITEM.functions.TakeOutCig = {
	name = "Take out Cigarette",
	onRun = function(item)
		local client = item.player
		local inv = client:getChar():getInv()
		item.PackNum = item:getData("cigLeft")

		if (item.PackNum > 1) then
			item:setData("cigLeft", item.PackNum - 1)

			inv:add("cigarette")
		else
			inv:add("cigarette")
			item:remove()
		end

		return false
	end
}

function ITEM:getDesc()
	local cigLeft = self:getData("cigLeft") or 10
	local description = "A pack of "..cigLeft.." cigarettes."

	if (cigLeft == 1) then
		description = "A lone cigarette in a pack."
	end

	return description
end