--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/food/sh_manhattan.lua
Size: 449 B

]===]
ITEM.name = "Manhattan"
ITEM.desc = "A tasty cocktail made up of whiskey, cherries. vermouth, and bitters."
ITEM.model = "models/manhattan/manhattan.mdl"
ITEM.category = "Food OR Drink"
ITEM.price = 5
ITEM.restore = 20
ITEM.functions.Use = {
    icon = "icon16/cup.png",
    sound = "eating_and_drinking/drinking.wav",
    onRun = function(item)
        item.player:SetHealth(math.min(item.player:Health() + item.restore, 100))
    end
}