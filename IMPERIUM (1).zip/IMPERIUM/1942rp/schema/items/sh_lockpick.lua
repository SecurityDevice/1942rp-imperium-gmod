--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/sh_lockpick.lua
Size: 4100 B

]===]
ITEM.name = "Lockpick"
ITEM.desc = "Try your luck at picking quietly through a door's lock"
ITEM.price = 1
ITEM.model = "models/gibs/metal_gib4.mdl"
ITEM.category = "Black Market"
ITEM.permit = "admin"

--- main server vvv
local blacklist = {2536, 2537, 2527, 2528, 2014, 2005, 2006, 2015, 2486, 2487, 2490, 2491, 2530, 2529, 2531, 2532, 2492, 2493, 2499, 2533, 1556, 2605, 1555, 1553, 1554, 1558, 1557, 1559, 1560}


ITEM.functions = {}



ITEM.functions.Use = {
    icon = "icon16/lock_open.png",


    onRun = function(item)
        local ply = item.player
        local char = ply:getChar()
        if ply:IsHandcuffed() then 
            ply:notify("You cannot lockpick a door while restrained!")
            return
        end
        
        
        local ent = ply:GetEyeTraceNoCursor().Entity

        if IsValid(ent) and ent:isDoor() then
            local dist = ent:GetPos():DistToSqr(ply:GetPos())
            local isBlacklisted = table.HasValue(blacklist, ent:MapCreationID())

            if isBlacklisted then
                ply:notify("This door cannot be lockpicked!")
                return false
            end
            print(dist)


            
            if dist < 9600 then


                local soundPath = "weapons/357/357_reload1.wav" -- replace with your sound file path
                local soundTimerName = "LockpickSound" .. ply:UserID()
                local soundRepeatCount = 0
                local maxSoundRepeats = 5 -- number of times to repeat the sound
    
                timer.Create(soundTimerName, 2, maxSoundRepeats, function()
                    if IsValid(ply) and soundRepeatCount < maxSoundRepeats then
                        ply:EmitSound(soundPath, 47)
                        soundRepeatCount = soundRepeatCount + 1
                    else
                        timer.Remove(soundTimerName)
                    end
                end)


                ply:Freeze(true)
                ply.isKickingDoor = true
                ply:setAction("Lockpicking Door", 12)

	

                timer.Simple(12, function()  -- Waiting for all kick sounds to finish + an extra 0.7 seconds before opening the door
                    if IsValid(ply) then
                        ply:Freeze(false)
                        ply.isKickingDoor = false
                    end
                    timer.Remove(soundTimerName)
                    if IsValid(ent) then
                        ent:Fire("unlock")
                      --  ent:EmitSound("physics/wood/wood_box_break1.wav",50)
                        ent:Fire("open")

                        local chance = math.random(1,2)
                        if chance == 1 then
                            ply:notify("Your lockpick broke upon getting the door open!")
                            item:remove()
                            return true  -- Removes the item from inventory
                        else
                            ply:notify("You managed to pick the lock without breaking your tool.")
                            return false  -- Keeps the item in inventory
                        end
                    end
                end)
            
                return false -- Important to have this here to prevent immediate removal of the item

        else
            ply:notify("You are too far to attempt to lockpick this door!")
            return false
        end
    else
        ply:notify("You are looking at an invalid door")
        return false
    end

end
}

ITEM.functions.Snap = {
    icon = "icon16/cross.png",
    onRun = function(item)
        local ply = item.player

        local actions = {
            "/me snaps a flimsy piece of steel in pieces.",
            "/me breaks a piece of steel with a swift motion.",
            "/me casually breaks apart a thin sheet of steel."
        }

        if ply:IsHandcuffed() then 
            ply:notify("You cannot complete this action while handcuffed")
            return
        end
        local action = actions[math.random(#actions)]
        ply:Say(action)
        item:remove()
    end
}