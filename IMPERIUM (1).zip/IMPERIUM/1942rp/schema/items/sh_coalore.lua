--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/sh_coalore.lua
Size: 176 B

]===]
ITEM.name = "Coal Ore"
ITEM.desc = "Ore mined from a coal node."
ITEM.price = 25
ITEM.model = "models/props_junk/rock001a.mdl"
ITEM.category = "Other"
ITEM.permit = "misc"