--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/outfit/sh_shirt.lua
Size: 355 B

]===]
ITEM.name = "Men's Shirt"
ITEM.desc = "A basic shirt."
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 50
ITEM.uniqueID = "_shirt"
ITEM.pacData = {}
ITEM.replacements = {
	{"_extended.mdl", "_shirt.mdl"},
	{"player/zelpa", "player/Suits"}
}
ITEM.category = "Outfit"
ITEM.outfitCategory = "outfit"