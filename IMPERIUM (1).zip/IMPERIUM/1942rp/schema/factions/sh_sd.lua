FACTION.name = "Reichsregierung"

FACTION.desc = "state"

FACTION.color = Color(127, 201, 255)

FACTION.isGloballyRecognized = false

FACTION.isDefault = false

FACTION_SD = FACTION.index