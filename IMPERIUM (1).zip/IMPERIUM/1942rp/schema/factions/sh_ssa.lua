FACTION.name = "Allgemeine-SS"

FACTION.desc = "Allg"

FACTION.color = Color(127, 201, 255)

FACTION.isGloballyRecognized = false

FACTION.isDefault = false

FACTION_SSA = FACTION.index