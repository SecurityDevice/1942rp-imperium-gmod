FACTION.name = "Deutsche Arbeitsfront"

FACTION.desc = "DAF"

FACTION.color = Color(127, 201, 255)

FACTION.isDefault = false

FACTION.isGloballyRecognized = false

FACTION_DAF = FACTION.index