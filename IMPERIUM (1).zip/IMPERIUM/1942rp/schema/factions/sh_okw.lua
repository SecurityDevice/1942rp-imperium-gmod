FACTION.name = "Oberkommando des Wehrmacht"
FACTION.desc = "Oberkommando des Wehrmacht" 
FACTION.color = Color(127, 201, 255)
FACTION.isGloballyRecognized = false
FACTION.isDefault = false

FACTION_OKW = FACTION.index