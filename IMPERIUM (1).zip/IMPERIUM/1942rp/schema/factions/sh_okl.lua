FACTION.name = "Oberkommando der Luftwaffe"

FACTION.desc = "OKL"

FACTION.color = Color(127, 201, 255)

FACTION.isGloballyRecognized = false

FACTION.isDefault = false

FACTION_OKL = FACTION.index