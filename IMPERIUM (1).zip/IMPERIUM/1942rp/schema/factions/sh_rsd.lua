FACTION.name = "Reichssicherheitsdienst"

FACTION.desc = "RSD"

FACTION.color = Color(127, 201, 255)

FACTION.isDefault = false

FACTION.isGloballyRecognized = false

FACTION_RSD = FACTION.index