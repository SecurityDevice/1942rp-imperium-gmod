FACTION.name = "Citizens of Berlin"
FACTION.desc = "Citizens."
FACTION.color = Color(127, 201, 255)
FACTION.isDefault = true
FACTION.models = {

	"models/player/suits/male_02_closed_coat_tie.mdl",
	"models/player/suits/male_04_closed_coat_tie.mdl",
	"models/player/suits/male_05_closed_coat_tie.mdl",
	"models/player/suits/male_06_closed_coat_tie.mdl",
	"models/player/suits/male_07_closed_coat_tie.mdl",
	"models/player/suits/male_08_closed_coat_tie.mdl",
	"models/player/suits/male_09_closed_coat_tie.mdl",
	"models/player/suits/male_10_closed_coat_tie.mdl",
	"models/princeminusa/suits/male_02_closed_tie.mdl",
	"models/princeminusa/suits/male_04_closed_tie.mdl",
	"models/princeminusa/suits/male_05_closed_tie.mdl",
    "models/princeminusa/suits/male_06_closed_tie.mdl",
    "models/princeminusa/suits/male_07_closed_tie.mdl",
    "models/princeminusa/suits/male_08_closed_tie.mdl",
	"models/princeminusa/suits/male_09_closed_tie.mdl"
	
}
	
FACTION.isGloballyRecognized = false

FACTION_civy = FACTION.index