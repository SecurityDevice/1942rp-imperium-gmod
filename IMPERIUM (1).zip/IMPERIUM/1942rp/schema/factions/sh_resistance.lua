FACTION.name = "Brandenburger"
FACTION.desc = "Brandenburger" 
FACTION.color = Color(127, 201, 255)
FACTION.isGloballyRecognized = false
FACTION.isDefault = false

FACTION_TEMPLATE5 = FACTION.index