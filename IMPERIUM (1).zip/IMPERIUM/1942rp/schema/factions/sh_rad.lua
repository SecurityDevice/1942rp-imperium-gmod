FACTION.name = "Reichsarbeitsdienst"

FACTION.desc = "RAD"

FACTION.color = Color(127, 201, 255)

FACTION.isDefault = false

FACTION.isGloballyRecognized = false

FACTION_RAD = FACTION.index