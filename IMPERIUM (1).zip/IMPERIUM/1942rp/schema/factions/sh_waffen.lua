FACTION.name = "1.SS Panzer Division Leibstandarte-SS 'Franz Brüning'"
FACTION.desc = "1.SS Panzer Division Leibstandarte-SS 'Franz Brüning'"
FACTION.color = Color(127, 201, 255)
FACTION.isGloballyRecognized = false
FACTION.isDefault = false

FACTION_WAFFEN = FACTION.index