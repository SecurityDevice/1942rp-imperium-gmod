FACTION.name = "Oberkommando des Heeres"
FACTION.desc = "Oberkommando des Heeres" 
FACTION.color = Color(127, 201, 255)
FACTION.isGloballyRecognized = false
FACTION.isDefault = false

FACTION_OKH = FACTION.index