FACTION.name = "Ordnungspolizei"

FACTION.desc = "orpo"

FACTION.color = Color(127, 201, 255)

FACTION.isGloballyRecognized = false

FACTION.isDefault = false

FACTION_POLICE = FACTION.index