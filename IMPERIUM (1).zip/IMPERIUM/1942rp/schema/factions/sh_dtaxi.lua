FACTION.name = "Kraft durch Freude"
FACTION.desc = "KdF"
FACTION.isGloballyRecognized = false
FACTION.isDefault = false
FACTION.isPublic = false
FACTION.color = Color(127, 201, 255)
FACTION_TAXI = FACTION.index