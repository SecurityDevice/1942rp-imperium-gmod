ITEM.name = "Erhard Bauschke Rudi Schuricke"
ITEM.music = "ww2/erhard bauschke rudi schuricke.ogg"