ITEM.name = "Du Bist So Zauberhaft"
ITEM.music = "ww2/du bist so zauberhaft.ogg"