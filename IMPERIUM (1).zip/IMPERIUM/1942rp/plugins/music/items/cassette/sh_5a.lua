ITEM.name = "Erika"
ITEM.music = "ww2/erika.ogg"