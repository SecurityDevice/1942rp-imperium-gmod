ITEM.name = "Dobbri Du Bis"
ITEM.music = "ww2/dobbri du bis.ogg"