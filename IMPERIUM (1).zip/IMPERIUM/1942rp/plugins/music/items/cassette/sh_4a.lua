ITEM.name = "Eric Harden Orchester Luigi Bernau"
ITEM.music = "ww2/eric harden orchester luigi bernau.ogg"