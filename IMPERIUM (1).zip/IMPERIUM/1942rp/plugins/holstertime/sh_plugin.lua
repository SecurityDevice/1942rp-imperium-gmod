-- oink.industries
-- lua source: gamemodes/1942rp/plugins/holstertime/sh_plugin.lua
PLUGIN.name = "Holster Time"
PLUGIN.author = "Chancer"
PLUGIN.desc = "Makes weapons take a few seconds to holster."
