ITEM.name = "Stolz Vanilla Beer"

ITEM.desc = "A pleasant aroma of milk chocolate, malt, and a touch of vanilla."
ITEM.model = "models/foodnhouseholditems/beer_stoltz.mdl"
ITEM.uniqueID = "beer2"
ITEM.price = 4
ITEM.permit = "food"
ITEM.abv = 10
ITEM.isFood = true
ITEM.empty = false
ITEM.noBusiness = false
ITEM.category = "Alcohol"
ITEM.base = "base_alcohol"