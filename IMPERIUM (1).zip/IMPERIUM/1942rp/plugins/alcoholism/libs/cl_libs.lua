﻿--------------------------------------------------------------------------------------------------------
function PLUGIN:RenderScreenspaceEffects()
    if LocalPlayer():GetNW2Int("nut_alcoholism_bac", 0) > 0 then DrawMotionBlur(self.AlcoholismAddAlpha, LocalPlayer():GetNW2Int("nut_alcoholism_bac", 0) / 100, self.AlcoholismEffectDelay) end
end

--------------------------------------------------------------------------------------------------------
function PLUGIN:DrawCharInfo(client, character, info)
    if client:IsDrunk() then info[#info + 1] = {"This Person Is Heavily Intoxicated", Color(245, 215, 110)} end
end
--------------------------------------------------------------------------------------------------------
