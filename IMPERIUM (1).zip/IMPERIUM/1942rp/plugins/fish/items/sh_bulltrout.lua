--------------------------------------------------------------------------------------------------------
ITEM.name = "Bull Trout"
ITEM.uniqueID = "Bull Trout"
ITEM.desc = "Something that resembles a Bull Trout.\nIt weighs 3 pounds."
ITEM.model = "models/props/cs_militia/fishriver01.mdl"
ITEM.hungerAmount = 15
ITEM.foodDesc = "A Bull Trout"
ITEM.quantity = 2
ITEM.price = 0
ITEM.width = 2
ITEM.height = 1
ITEM.noBusiness = true
--------------------------------------------------------------------------------------------------------