--------------------------------------------------------------------------------------------------------
ITEM.name = "Rainbow Trout"
ITEM.uniqueID = "Rainbow Trout"
ITEM.desc = "Something that resembles a Rainbow Trout.\nIt weighs 3 pounds."
ITEM.model = "models/props/cs_militia/fishriver01.mdl"
ITEM.hungerAmount = 15
ITEM.foodDesc = "A Rainbow Trout"
ITEM.quantity = 2
ITEM.price = 0
ITEM.width = 3
ITEM.height = 1
ITEM.noBusiness = true
--------------------------------------------------------------------------------------------------------