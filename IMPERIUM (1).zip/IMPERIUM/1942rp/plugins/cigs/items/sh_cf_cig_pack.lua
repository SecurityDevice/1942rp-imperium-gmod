ITEM.name = "Cigarette Pack"
ITEM.desc = "A pack of cigarettes produced by a cigarette factory."
ITEM.model = "models/props_junk/cardboard_box003a.mdl"
