ITEM.name = "Cigarette Machine Engine Upgrade"
ITEM.desc = "An engine upgrade for the cigarette machine."
ITEM.model = "models/maxofs2d/thruster_propeller.mdl"
ITEM.noDrop = true

ITEM.functions.Place = {
	name = "Place",
	onRun = function(item)
		local client = item.player

		local ent = ents.Create("cf_engine_upgrade")
		if (!ent) then
			client:notify("Failed to place.")
			return
		end

		local startpos = client:EyePos()
		local mins = ent:OBBMins()
		local maxs = ent:OBBMaxs()
		local traceResult = util.TraceHull({
			start = startpos,
			endpos = startpos + 150*client:EyeAngles():Forward(),
			mins = mins,
			maxs = maxs,
			filter = client
		})

		if (traceResult.Fraction < 0.25) then
			client:notify("There isn't enough space here.")
			ent:Remove()
			return
		end

		local zOffset = (mins.z > maxs.z) and mins.z or maxs.z
		ent:SetPos(traceResult.HitPos + Vector(0, 0, zOffset))
		ent:Spawn()
	end
}

