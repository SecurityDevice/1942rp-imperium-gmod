PLUGIN.VehicleRepairEnabled = true
---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------
PLUGIN.VehicleRepairTime = 60
---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------
PLUGIN.VehicleRepairCost = 500
---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------
PLUGIN.VehicleTax = 5
---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------
PLUGIN.SalesTax = 5
---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------
PLUGIN.VehicleCategories = {"Economy Vehicles", "Worker Vehicles", "Luxury Vehicles",}
PLUGIN.Vehicles = {
    ["codww2_cta"] = {
        Name = "Citroen Traction Avant",
        Category = "Luxury Vehicles",
        Identifier = "codww2_cta",
        Model = "models/citroen_traction.mdl",
        Price = 30000,
    },
    ["sim_fphys_w150"] = {
        Name = "Mercedes W150",
        Category = "Luxury Vehicles",
        Identifier = "sim_fphys_w150",
        Model = "models/w150.mdl",
        Price = 50000,
    },
    ["codww2opel_civ"] = {
        Name = "Open Blitz Civilian",
        Category = "Worker Vehicles",
        Identifier = "codww2opel_civ",
        Model = "models/codww2blitz_civ.mdl",
        Price = 10000,
    },
    ["codww2opel_fuel"] = {
        Name = "Fuel Truck",
        Category = "Worker Vehicles",
        Identifier = "codww2opel_fuel",
        Model = "models/codww2blitz_fuel.mdl",
        Price = 10000,
    },
    ["codww2peugeottruck"] = {
        Name = "Peugeot Truck",
        Category = "Worker Vehicles",
        Identifier = "codww2peugeottruck",
        Model = "models/codww2peugeottruck.mdl",
        Price = 10000,
    },
    ["vw38"] = {
        Name = "Volkswagen 38",
        Category = "Economy Vehicles",
        Identifier = "vw38",
        Model = "models/codww2vw38.mdl",
        Price = 6500,
    },
    ["codww2opelkadett"] = {
        Name = "Opel Kadett",
        Category = "Luxury Vehicles",
        Identifier = "codww2opelkadett",
        Model = "models/codww2_opelkadett.mdl",
        Price = 20000,
    },
        ["codww2renault"] = {
        Name = "Renault Sedan",
        Category = "Economy Vehicles",
        Identifier = "codww2renault",
        Model = "models/codww2_renault.mdl",
        Price = 6500,
    },
    }
---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------