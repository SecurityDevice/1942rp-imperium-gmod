ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Public Garage"
ENT.Author = "Leonheart"
ENT.Category = "Imperium Entities"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.DrawEntityInfo = true