ENT.Type = "ai"
ENT.Base = "base_ai"
ENT.PrintName = "Orpo Car Dealer NPC"
ENT.Author = "Leonheart"
ENT.Category = "Imperium Entities"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.DrawEntityInfo = true