--------------------------------------------------------------------------------------------------------
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Import Item"
ENT.Author = "Leonheart"
ENT.Category = "Glance RolePlay Entities"
ENT.Spawnable = false
ENT.AdminOnly = false
--------------------------------------------------------------------------------------------------------