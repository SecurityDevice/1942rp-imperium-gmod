---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------
local playerMeta = FindMetaTable("Player")
------------------------------------------------------------------------------------------
local PLUGIN = PLUGIN
-------------------------------------------------------------------------------------------
netstream.Hook("OpenTraffickMenu", function(table)
    if not table then
        LocalPlayer():ChatPrint("I can't sell anything to ya")
        return
    end

    local frame = vgui.Create("DFrame")
    frame:SetTitle("Categories")
    frame:SetSize(400, 400)
    frame:MakePopup()
    frame:Center()
    for y, x in pairs(PLUGIN.ImportableItemsCategories) do
        frame.button = vgui.Create("DButton", frame)
        frame.button:SetText(x)
        frame.button:SetHeight(25)
        frame.button:Dock(TOP)
        frame.button.DoClick = function()
            frame:Remove()
            frame = vgui.Create("DFrame")
            frame:SetTitle(x)
            frame:SetSize(400, 400)
            frame:MakePopup()
            frame:Center()
            frame.scroll = vgui.Create("DScrollPanel", frame)
            frame.scroll:Dock(FILL)
            for itemName, itemData in pairs(table) do
                if itemData.category == x then
                    frame.button = vgui.Create("DButton", frame.scroll)
                    frame.button:SetText(tostring(itemName) .. " - $" .. itemData.price)
                    frame.button:SetHeight(25)
                    frame.button:Dock(TOP)
                    frame.button.DoClick = function() netstream.Start("BuyFromTraffickMenu", itemData.item, itemData.price) end
                end
            end
        end
    end
end)

---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------
function playerMeta:SetWeighPoint(name, vector, OnReach)
    hook.Add("HUDPaint", "WeighPoint", function()
        local dist = self:GetPos():Distance(vector)
        local spos = vector:ToScreen()
        local howclose = math.Round(math.floor(dist) / 40)
        if not spos then return end
        render.SuppressEngineLighting(true)
        surface.SetFont("WB_Large")
        draw.DrawText(name .. "\n" .. howclose .. " Meters\n", "CenterPrintText", spos.x, spos.y, Color(123, 57, 209), TEXT_ALIGN_CENTER)
        render.SuppressEngineLighting(false)
        if howclose <= 3 then RunConsoleCommand("weighpoint_stop") end
    end)

    concommand.Add("weighpoint_stop", function()
        hook.Add("HUDPaint", "WeighPoint", function() end)
        if IsValid(OnReach) then OnReach() end
    end)
end

---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------
net.Receive("packagewaypoint", function()
    local vector = net.ReadVector()
    LocalPlayer():SetWeighPoint("Your Package", vector)
end)
---------------------------------------------------------------------------[[//////////////////]]---------------------------------------------------------------------------