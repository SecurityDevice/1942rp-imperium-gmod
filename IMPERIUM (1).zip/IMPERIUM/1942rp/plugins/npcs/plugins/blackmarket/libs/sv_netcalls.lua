util.AddNetworkString("packagewaypoint")
------------------------------------------------------------------------------------------
local PLUGIN = PLUGIN
-------------------------------------------------------------------------------------------
netstream.Hook("BuyFromTraffickMenu", function(client, item, price)
    local itemTable = nut.item.list[item]
    local character = client:getChar()
    if character:hasMoney(price) then
        character:takeMoney(price)
        client:notify("You've placed an order for a " .. itemTable.name .. " for RM" .. price .. ". It will arrive in " .. PLUGIN.ImportTime .. " seconds.")
        timer.Create(client:UniqueID() .. "_Import_" .. item, PLUGIN.ImportTime, 0, function()
            local locationNames = table.GetKeys(PLUGIN.DropLocation)
            local randomLocationName = table.Random(locationNames)
            local randomLocation = PLUGIN.DropLocation[randomLocationName]
            local imported = ents.Create("import_item")
            imported:SetPos(randomLocation)
            imported:SetNWInt("imported_owner", client:EntIndex())
            imported:SetNWString("imported_item", item)
            imported:Spawn()
            net.Start("packagewaypoint")
            net.WriteVector(imported:GetPos())
            net.Send(client)
            client:notify("Your " .. itemTable.name .. " has arrived! It was spawned in " .. randomLocationName .. "!")
            timer.Remove(client:UniqueID() .. "_Import_" .. item)
        end)
    else
        client:notify("You cannot afford this shipment!")
    end
end)

-------------------------------------------------------------------------------------------
netstream.Hook("OpenTraffickMenu", function(client, ent) netstream.Start(client, "OpenTraffickMenu", PLUGIN.ImportableItems[client:Team()]) end)
-------------------------------------------------------------------------------------------