-------------------------------------------------------------------------------------------
hook.Add("OpenTraffickMenuHook", "OpenTraffickMenuHook", function(client) netstream.Start("OpenTraffickMenu", client) end)
-------------------------------------------------------------------------------------------