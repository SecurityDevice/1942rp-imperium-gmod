local PLUGIN = PLUGIN or {}
PLUGIN.name = "Animations"
PLUGIN.author = "Leonheart#7476"
PLUGIN.desc = "Ported EGM Animations to Commands"
nut.util.include("cl_plugin.lua")