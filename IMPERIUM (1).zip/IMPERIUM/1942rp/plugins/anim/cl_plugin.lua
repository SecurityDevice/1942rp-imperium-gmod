nut.command.add("anim", {
    onRun = function(client, arguments) end
})