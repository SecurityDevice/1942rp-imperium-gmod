PLUGIN.name = "Spawn Saver"
PLUGIN.author = "Chessnut."
PLUGIN.desc = "Saves the position of a character."
if SERVER then
	function PLUGIN:CharacterPreSave(character)
		local client = character:getPlayer()
		if IsValid(client) then character:setData("pos", {client:GetPos(), client:EyeAngles(), game.GetMap()}) end
	end

	util.AddNetworkString("syncCharData")
	function PLUGIN:PlayerLoadedChar(client, character, lastChar)
		if lastChar then
			net.Start("syncCharData")
			net.WriteInt(lastChar:getID(), 32)
			net.Send(client)
			client:Spawn()
		end

		timer.Simple(0, function()
			client:Spawn()
			if IsValid(client) then
				local position = character:getData("pos")
				if position then
					if position[3] and position[3]:lower() == game.GetMap():lower() then
						client:SetPos(position[1].x and position[1] or client:GetPos())
						client:SetEyeAngles(position[2].p and position[2] or Angle(0, 0, 0))
					end

					character:setData("pos", nil)
				end
			end
		end)
	end
end