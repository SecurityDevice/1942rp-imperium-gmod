NAME = "English"
LANGUAGE = {
	crafting = "Crafting",
	craftingtable = "Fabricator",
	req_moremat = "You need more materials to craft %s.",
	req_blueprint = "You need a blueprint of %s to craft %s.",
	req_morespace = "You need more space to get result.",
	donecrafting = "You have crafted %s.",
	icat_material = "Materials",

	craft_menu_tip1 = "You can craft items by clicking the icons in the list.",
	craft_menu_tip2 = "The icon with book means that item needs a blueprint to be crafted.",
	
	crft_text = "Crafting %s\n%s\n\nRequirements:\n"
}