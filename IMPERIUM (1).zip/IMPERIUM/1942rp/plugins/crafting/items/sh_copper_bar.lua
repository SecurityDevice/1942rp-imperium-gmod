ITEM.name = "Copper Bar"
ITEM.desc = "A refined bar of copper."
ITEM.price = 100
ITEM.model = "models/gibs/metal_gib3.mdl"
ITEM.category = "Minerals"
ITEM.permit = "misc"