ITEM.name = "Iron Bar"
ITEM.desc = "A refined bar of iron."
ITEM.price = 100
ITEM.model = "models/gibs/metal_gib2.mdl"
ITEM.category = "Minerals"
ITEM.permit = "misc"