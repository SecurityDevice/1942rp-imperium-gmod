if CLIENT then
	netstream.Hook("nut_bodygroupclosetopenmenu", function()
		vgui.Create("nut_bodygroupcloset")
	end)
end