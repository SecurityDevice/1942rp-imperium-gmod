netstream.Hook("nut_bodygroupclosetapplychanges", function(client, data)
    for k, v in ipairs(ents.FindByClass("nut_closet")) do
        if v:GetPos():Distance(client:GetPos()) < 128 then
            client:SetSkin(data.skin or 0)
            client:getChar():setData("skin", data.skin or 0)
            local group = client:getChar():getData("groups") or {}

            for k2, v2 in pairs(data.groups) do
                client:SetBodygroup(k2, v2)
                group[k2] = v2
            end

            client:getChar():setData("groups", group)

            return
        end
    end
end)

netstream.Hook("onnut_bodygroupclosetclose", function(client)
    for k, v in ipairs(ents.FindByClass("nut_closet")) do
        if v:GetPos():Distance(client:GetPos()) < 128 then
            v:EmitSound("items/ammocrate_close.wav")
        end
    end
end)