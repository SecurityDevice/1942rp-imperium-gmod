-- oink.industries
-- lua source: gamemodes/1942rp/plugins/cards/items/sh_carddeck.lua
ITEM.name = "Deck of Cards"
ITEM.desc = "A deck of 1932 Skat-Karte Nr. 88 Playing Cards"
ITEM.price = 4
ITEM.model = "models/freeman/owain_playingcards.mdl"
ITEM.skin = 1
ITEM.uniqueID = "carddeck"
