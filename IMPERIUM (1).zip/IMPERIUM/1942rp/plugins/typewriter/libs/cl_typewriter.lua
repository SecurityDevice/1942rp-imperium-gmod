----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function PLUGIN:LoadFonts(font)
    surface.CreateFont(
        "TypewriterTitleFont",
        {
            font = "Roboto",
            size = 16,
            weight = 300,
        }
    )

    surface.CreateFont(
        "TypewriterGeneralFont",
        {
            font = "Roboto",
            size = 16,
            weight = 500,
        }
    )

    surface.CreateFont(
        "TypewriterButtonFont",
        {
            font = "Roboto",
            size = 14,
            weight = 500,
        }
    )
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------