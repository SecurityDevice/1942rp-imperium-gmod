ITEM.name = "Marijuana"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "A psychoactive drug from the Cannabis plant intended for medical or recreational use."
ITEM.addictChance = 0 --no addictive properties
ITEM.effect = "drug_weed"
ITEM.color = Color(50, 255, 50)
ITEM.category = "Drugs"

