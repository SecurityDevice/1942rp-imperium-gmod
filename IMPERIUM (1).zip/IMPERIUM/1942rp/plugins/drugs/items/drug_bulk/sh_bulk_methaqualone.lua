ITEM.name = "Methaqualone Powder"
ITEM.desc = "A large jar of powdered methaqualone."
ITEM.category = "Drugs"
ITEM.model = "models/props_lab/jar01a.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.logCity = true

function ITEM:getDesc()
	if self:getData("shippedMiami") then
		return self.desc.."\n\nOriginated in: UnionCity"
	elseif self:getData("shippedNewYork") then
		return self.desc.."\n\nOriginated in: SouthSide"
	else
		return self.desc.."\n\nOriginated in: Unknown"
	end
end