ITEM.name = "Oil Container"
ITEM.desc = "A large barrel of crude oil."
ITEM.category = "Drugs"
ITEM.model = "models/props_c17/oildrum001.mdl"
ITEM.width = 2
ITEM.height = 2