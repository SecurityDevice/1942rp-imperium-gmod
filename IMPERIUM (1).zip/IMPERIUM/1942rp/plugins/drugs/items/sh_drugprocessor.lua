-------------------------------------------------------------------------------------------
ITEM.name = "Drug Lab"
-------------------------------------------------------------------------------------------
ITEM.model = "models/props_junk/cardboard_box002a_gib01.mdl"
-------------------------------------------------------------------------------------------
ITEM.desc = "A complex drug lab with all the tools required to process drugs."
-------------------------------------------------------------------------------------------
ITEM.width = 2
-------------------------------------------------------------------------------------------
ITEM.height = 2
-------------------------------------------------------------------------------------------
ITEM.functions.Weed = {
    name = "Process Weed",
    icon = "icon16/cog.png",
    sound = "buttons/lightswitch2.wav",
    onRun = function(item)
        local client = item.player
        local inventory = client:getChar():getInv()
        local Unprocessed = "unprocessedweed"
        local UnprocessedName = "Unprocessed Weed"
        local FinalItem = "weed"
        local FinalItemName = "Weed"
        if not IsValid(item.entity) then
            client:notify("The drug lab must be on the ground")

            return false
        end

        local requirement = inventory:getFirstItemOfType(Unprocessed)
        if not requirement then
            client:notify("You need " .. UnprocessedName .. "!")

            return false
        end

        requirement:remove()
        item:setData("producing2", CurTime())
        client:notify("The drug is cooking.")
        timer.Simple(
            600,
            function()
                if item then
                    item:setData("producing2", nil)
                    client:notify("The " .. FinalItemName .. " is Ready!")
                    timer.Create(
                        item.uniqueID .. "_druglab_" .. client:SteamID(),
                        1,
                        5,
                        function()
                            if not inventory:add(FinalItem) then
                                nut.item.spawn(FinalItem, item:getEntity():GetPos() + item:getEntity():GetUp() * 50)
                                client:notify("You lack space in your inventory! Dropping " .. FinalItemName .. " on the ground!")
                            else
                                client:notify("Your " .. FinalItemName .. " is ready!")
                            end
                        end
                    )
                end
            end
        )

        return false
    end,
    onCanRun = function(item)
        if item:getData("producing2") ~= nil then return false end

        return true
    end
}

-------------------------------------------------------------------------------------------
ITEM.functions.Heroin = {
    name = "Process Heroin",
    icon = "icon16/cog.png",
    sound = "buttons/lightswitch2.wav",
    onRun = function(item)
        local client = item.player
        local inventory = client:getChar():getInv()
        local Unprocessed = "unprocessedheroin"
        local UnprocessedName = "Unprocessed Heroin"
        local FinalItem = "heroin"
        local FinalItemName = "Heroin"
        if not IsValid(item.entity) then
            client:notify("The drug lab must be on the ground")

            return false
        end

        local requirement = inventory:getFirstItemOfType(Unprocessed)
        if not requirement then
            client:notify("You need " .. UnprocessedName .. "!")

            return false
        end

        requirement:remove()
        item:setData("producing2", CurTime())
        client:notify("The drug is cooking.")
        timer.Simple(
            600,
            function()
                if item then
                    item:setData("producing2", nil)
                    client:notify("The " .. FinalItemName .. " is Ready!")
                    timer.Create(
                        item.uniqueID .. "_druglab_" .. client:SteamID(),
                        1,
                        5,
                        function()
                            if not inventory:add(FinalItem) then
                                nut.item.spawn(FinalItem, item:getEntity():GetPos() + item:getEntity():GetUp() * 50)
                                client:notify("You lack space in your inventory! Dropping " .. FinalItemName .. " on the ground!")
                            else
                                client:notify("Your " .. FinalItemName .. " is ready!")
                            end
                        end
                    )
                end
            end
        )

        return false
    end,
    onCanRun = function(item)
        if item:getData("producing2") ~= nil then return false end

        return true
    end
}

-------------------------------------------------------------------------------------------
ITEM.functions.Meth = {
    name = "Process Meth",
    icon = "icon16/cog.png",
    sound = "buttons/lightswitch2.wav",
    onRun = function(item)
        local client = item.player
        local inventory = client:getChar():getInv()
        local Unprocessed = "unprocessedmeth"
        local UnprocessedName = "Meth Brick"
        local FinalItem = "meth"
        local FinalItemName = "Meth Baggie"
        if not IsValid(item.entity) then
            client:notify("The drug lab must be on the ground")

            return false
        end

        local requirement = inventory:getFirstItemOfType(Unprocessed)
        if not requirement then
            client:notify("You need " .. UnprocessedName .. "!")

            return false
        end

        requirement:remove()
        item:setData("producing2", CurTime())
        client:notify("The drug is cooking.")
        timer.Simple(
            600,
            function()
                if item then
                    item:setData("producing2", nil)
                    client:notify("The " .. FinalItemName .. " is Ready!")
                    timer.Create(
                        item.uniqueID .. "_druglab_" .. client:SteamID(),
                        1,
                        5,
                        function()
                            if not inventory:add(FinalItem) then
                                nut.item.spawn(FinalItem, item:getEntity():GetPos() + item:getEntity():GetUp() * 50)
                                client:notify("You lack space in your inventory! Dropping " .. FinalItemName .. " on the ground!")
                            else
                                client:notify("Your " .. FinalItemName .. " is ready!")
                            end
                        end
                    )
                end
            end
        )

        return false
    end,
    onCanRun = function(item)
        if item:getData("producing2") ~= nil then return false end

        return true
    end
}

-------------------------------------------------------------------------------------------
ITEM.functions.Cocaine = {
    name = "Process Cocaine",
    icon = "icon16/cog.png",
    sound = "buttons/lightswitch2.wav",
    onRun = function(item)
        local client = item.player
        local inventory = client:getChar():getInv()
        local Unprocessed = "unprocessedcocaine"
        local UnprocessedName = "Cocaine Brick"
        local FinalItem = "cocaine"
        local FinalItemName = "Cocaine Baggie"
        if not IsValid(item.entity) then
            client:notify("The drug lab must be on the ground")

            return false
        end

        local requirement = inventory:getFirstItemOfType(Unprocessed)
        if not requirement then
            client:notify("You need " .. UnprocessedName .. "!")

            return false
        end

        requirement:remove()
        item:setData("producing2", CurTime())
        client:notify("The drug is cooking.")
        timer.Simple(
            600,
            function()
                if item then
                    item:setData("producing2", nil)
                    client:notify("The " .. FinalItemName .. " is Ready!")
                    timer.Create(
                        item.uniqueID .. "_druglab_" .. client:SteamID(),
                        1,
                        5,
                        function()
                            if not inventory:add(FinalItem) then
                                nut.item.spawn(FinalItem, item:getEntity():GetPos() + item:getEntity():GetUp() * 50)
                                client:notify("You lack space in your inventory! Dropping " .. FinalItemName .. " on the ground!")
                            else
                                client:notify("Your " .. FinalItemName .. " is ready!")
                            end
                        end
                    )
                end
            end
        )

        return false
    end,
    onCanRun = function(item)
        if item:getData("producing2") ~= nil then return false end

        return true
    end
}

-------------------------------------------------------------------------------------------
function ITEM:getDesc()
    local desc = self.desc
    if self:getData("producing2") ~= nil then
        desc = desc .. "\nIt is currently producing something."
    end

    return Format(desc)
end

-------------------------------------------------------------------------------------------
ITEM.functions.take.onCanRun = function(item) return IsValid(item.entity) and item:getData("producing2", 0) == 0 end
-------------------------------------------------------------------------------------------