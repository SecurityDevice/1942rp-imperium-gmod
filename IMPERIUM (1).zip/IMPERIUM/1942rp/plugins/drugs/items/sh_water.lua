ITEM.name = "Water Jug"
ITEM.model = "models/props_junk/garbage_plasticbottle003a.mdl"
ITEM.desc = "A Water Jug."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 2
ITEM.category = "Drugs"