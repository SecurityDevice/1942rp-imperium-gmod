ITEM.name = "Superior Meth Barrel"
ITEM.desc = "A Barrel Of Superior Meth."
ITEM.category = "Drugs"
ITEM.model = "models/props_c17/oildrum001.mdl"
ITEM.width = 3
ITEM.height = 3
ITEM.logCity = true

function ITEM:getDesc()
	if self:getData("shippedMiami") then
		return self.desc.."\n\nOriginated in: UnionCity"
	elseif self:getData("shippedNewYork") then
		return self.desc.."\n\nOriginated in: SouthSide"
	else
		return self.desc.."\n\nOriginated in: Unknown"
	end
end