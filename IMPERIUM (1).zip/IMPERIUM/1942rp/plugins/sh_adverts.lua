PLUGIN.name = "Advertising"
PLUGIN.author = "Hawk"
PLUGIN.desc = "Adds an advert command."

nut.chat.register("announcement", {
	onCanSay =  function(speaker, text)
		return speaker:IsAdmin()
	end,
	onCanHear = 1000000,
	onChatAdd = function(speaker, text)
		chat.AddText(Color(255, 0, 0), " [Admin Announcement] ", color_white, text)
	end,
	prefix = {"/announce"}
})

nut.chat.register("advert", {
	onCanSay =  function(speaker, text)	
		if speaker:getChar():hasMoney(4) then
			speaker:getChar():takeMoney(4)
			speaker:notify("Your advertisement has been posted successfully.")
			return true
		else 
			speaker:notify("You lack sufficient funds to advertise.")
			return false 
		end
	end,
	onChatAdd = function(speaker, text)
		chat.AddText( Color(251, 255, 0), " [Advertisement by " .. speaker:Nick() .. "] ", color_white, text)
	end,
	prefix = {"/advert"},
	noSpaceAfter = true,
	filter = "advertisements"
})

function PLUGIN:PlayerLoadedChar(client, id)
    client:notify('Welcome to our server, if you need help getting started, use @ to contact a staff member.')
end