resource.AddWorkshop("675824914")
