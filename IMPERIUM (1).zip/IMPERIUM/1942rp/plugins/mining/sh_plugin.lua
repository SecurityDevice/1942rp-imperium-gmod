PLUGIN.name = "Mining"
PLUGIN.author = "Gr0wn, berko"
PLUGIN.desc = "Adds trees and rocks where you can harvest them."

nut.util.include("sv_plugin.lua")
nut.util.include("cl_plugin.lua")
