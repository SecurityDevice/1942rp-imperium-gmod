ENT.Type = "anim"
ENT.PrintName = "Iron Node"
ENT.Category = "Mining"
ENT.Spawnable = true
ENT.AdminOnly = true
