AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

ENT.ironCount = 0

function ENT:Initialize()
	self:SetModel( "models/props_wasteland/rockgranite02c.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetColor( Color( 139, 69, 19, 255 ) )
	
	self:GetPhysicsObject():Wake()
	 
	self.ironCount = 0
end

function ENT:OnTakeDamage( dmg )
	local ply = dmg:GetAttacker()
	if ( !ply:IsPlayer() ) then return end
	if ( !ply:Alive() ) then return end
	if !( ply:GetActiveWeapon():GetClass() == "weapon_hl2pickaxe" ) then return end
	
	local char = ply:getChar()
	if (!char) then return end
	local inv = char:getInv()
	if (self.ironCount < 15) then
		self.ironCount = self.ironCount + 1
		return
	end
	s = inv:add( "ironore" )
	ply:ChatPrint("You have mined one iron ore.")
	self.ironCount = 0
end
