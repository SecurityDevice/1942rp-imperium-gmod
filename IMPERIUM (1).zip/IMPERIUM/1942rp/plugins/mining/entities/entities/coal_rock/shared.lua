ENT.Type = "anim"
ENT.PrintName = "Coal Node"
ENT.Category = "Mining"
ENT.Spawnable = true
ENT.AdminOnly = true
