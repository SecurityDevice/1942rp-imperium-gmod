ENT.Type = "anim"
ENT.PrintName = "Tree"
ENT.Category = "Mining"
ENT.Spawnable = true
ENT.AdminOnly = true
