AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

ENT.treeCount = 0

function ENT:Initialize()
	self:SetModel( "models/props_foliage/tree_poplar_01.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_VPHYSICS )
	
	self:GetPhysicsObject():Wake()

	self.treeCount = 0
end

function ENT:OnTakeDamage( dmg )
	local ply = dmg:GetAttacker()
	if ( !ply:IsPlayer() ) then return end
	if ( !ply:Alive() ) then return end
	if !( ply:GetActiveWeapon():GetClass() == "weapon_hl2axe" ) then return end
	
	local char = ply:getChar()
	if (!char) then return end
	local inv = char:getInv()
	if (self.treeCount < 8) then 
		self.treeCount = self.treeCount + 1 
		hitsleft = 8 - self.treeCount
		if (hitsleft % 2 == 0 ) then 
			ply:ChatPrint("You hit the tree with your axe.. " ..hitsleft.. " chops left until you get some wood.")
			return 
		else 
			return 
		end
	end
	s = inv:add( "wood" )
	ply:ChatPrint("You have chopped some wood.")
	self.treeCount = 0
end