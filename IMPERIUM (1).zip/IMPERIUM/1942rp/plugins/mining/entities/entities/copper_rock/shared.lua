ENT.Type = "anim"
ENT.PrintName = "Copper Node"
ENT.Category = "Mining"
ENT.Spawnable = true
ENT.AdminOnly = true