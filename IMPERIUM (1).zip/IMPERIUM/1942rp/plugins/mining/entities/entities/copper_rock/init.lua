AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

ENT.copperCount = 0

function ENT:Initialize()
	self:SetModel( "models/props_wasteland/rockgranite03a.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetColor( Color( 255, 128, 0, 255 ) )
	
	self:GetPhysicsObject():Wake()
	 
	self.copperCount = 0
end

function ENT:OnTakeDamage( dmg )
	local ply = dmg:GetAttacker()
	if ( !ply:IsPlayer() ) then return end
	if ( !ply:Alive() ) then return end
	if !( ply:GetActiveWeapon():GetClass() == "weapon_hl2pickaxe" ) then return end
	
	local char = ply:getChar()
	if (!char) then return end
	local inv = char:getInv()
	if (self.copperCount < 15) then
		self.copperCount = self.copperCount + 1
		return
	end
	s = inv:add( "copperore" )
	ply:ChatPrint("You have mined one copper ore.")
	self.copperCount = 0
end
