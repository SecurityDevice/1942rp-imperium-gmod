hook.Add("PreDrawHalos", "DrawHalo", function()
	if !(IsValid(LocalPlayer())) then return end
	if (LocalPlayer():GetActiveWeapon() == NULL) then return end
	
    local tr = util.GetPlayerTrace(LocalPlayer())
    local trRes = util.TraceLine(tr)
    local haloColor = nut.config.get("color")

    
    for _,ent in pairs(ents.FindInSphere(LocalPlayer():GetPos(), 1500)) do
    	
        if ent:GetClass() == "copper_rock" or ent:GetClass() == "coal_rock" or ent:GetClass() == "iron_rock" then
             if LocalPlayer():GetActiveWeapon():GetClass() == "weapon_hl2pickaxe" then
                 halo.Add({ent}, haloColor, 5, 5, 2)            continue
             end
         end
        if ent:GetClass() == "tree" then
             if LocalPlayer():GetActiveWeapon():GetClass() == "weapon_hl2axe" then
                 halo.Add({ent}, haloColor, 5, 5, 2)     
                continue
            end
        end


    end
end)
