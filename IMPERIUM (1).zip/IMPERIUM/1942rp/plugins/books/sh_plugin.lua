-- oink.industries
-- lua source: gamemodes/1942rp/plugins/books/sh_plugin.lua
PLUGIN.name = "Books"
PLUGIN.author = "Chessnut"
PLUGIN.desc = "Adds books that you can read."
