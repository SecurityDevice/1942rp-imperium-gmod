
if (CLIENT) then
	local HELP_DEFAULT

	hook.Add("CreateMenuButtons", "nutHelpMenu", function(tabs)		
		HELP_DEFAULT = [[
			<div id="parent"><div id="child">
				<center>
				    <img src="https://cdn.discordapp.com/attachments/1177288095612293202/1228045887188762694/ares-networks_org.png?ex=662a9ddb&is=661828db&hm=b0e11b93ab6a2e3094c48eb32adcc4f5a501ec6d28dd73eb9ca3484fe631a8f1&"></img>
				</center>
			</div></div>
		]]

		tabs["help"] = function(panel)
			local html
			local header = [[<html>
			<head>
				<style>
					@import url(http://fonts.googleapis.com/earlyaccess/jejugothic.css);

					#parent {
					    padding: 5% 0;
					}

					#child {
					    padding: 10% 0;
					}

					body {
						color: #FAFAFA;
						font-family: 'Jeju Gothic', serif;
						-webkit-font-smoothing: antialiased;
					}

					h2 {
						margin: 0;
					}
				</style>
			</head>
			<body>
			]]

			local tree = panel:Add("DTree")
			tree:SetPadding(5)
			tree:Dock(LEFT)
			tree:SetWide(180)
			tree:DockMargin(0, 0, 15, 0)
			tree.OnNodeSelected = function(this, node)
				if (node.onGetHTML) then
					html:SetHTML(header..node:onGetHTML().."</body></html>")
				end
			end

			html = panel:Add("DHTML")
			html:Dock(FILL)
			html:SetHTML(header..HELP_DEFAULT)

			local tabs = {}
			hook.Run("BuildHelpMenu", tabs)

			for k, v in SortedPairs(tabs) do
				if (type(v) != "function") then
					local source = v

					v = function() return tostring(source) end
				end

				tree:AddNode(L(k)).onGetHTML = v or function() return "" end
			end
		end
	end)
end

hook.Add("BuildHelpMenu", "nutBasicHelp", function(tabs)
	tabs["Armed Forces Discord"] = function(node)
		local body = '<center><img src="https://i.imgur.com/Ri5wYVz.jpeg"></img></center>'
		return body
	end

	tabs["City Penal Code"] = function(node)
		local body = [[ 
			<div id="parent"><div id="child">
				<center>
				    <img src="https://cdn.discordapp.com/attachments/1199104242946949191/1214335080114290699/logo.png?ex=65f8bcac&is=65e647ac&hm=9c4f7255cacdb57a764d88e24b1314c5d57d1a27b6d7448664ab7308ffaba640&"></img>
				</center>
			</div></div>
		]]
		local f = vgui.Create("DFrame")
		f:SetSize(ScrW()*0.8, ScrH()*0.8)
		f:SetTitle("Discord")
		f:Center()
		f:MakePopup()
		local h = vgui.Create("DHTML", f)
		h:Dock(FILL)
		h:OpenURL("https://discord.gg/du7mpFPA9w")
		return body
	end
	tabs["Ministry of Interior Discord"] = function(node)
		local body = [[ 
			<div id="parent"><div id="child">
				<center>
				    <img src="https://cdn.discordapp.com/attachments/1199104242946949191/1214335080114290699/logo.png?ex=65f8bcac&is=65e647ac&hm=9c4f7255cacdb57a764d88e24b1314c5d57d1a27b6d7448664ab7308ffaba640&"></img>
				</center>
			</div></div>
		]]
		local f = vgui.Create("DFrame")
		f:SetSize(ScrW()*0.8, ScrH()*0.8)
		f:SetTitle("Ministry of Interior Discord")
		f:Center()
		f:MakePopup()
		local h = vgui.Create("DHTML", f)
		h:Dock(FILL)
		h:OpenURL("https://discord.gg/6JneQNgFEs")
		return body
	end
	tabs["Discord Support"] = function(node)
		local body = [[ 
			<div id="parent"><div id="child">
				<center>
				    <img src="https://cdn.discordapp.com/attachments/1199104242946949191/1214335080114290699/logo.png?ex=65f8bcac&is=65e647ac&hm=9c4f7255cacdb57a764d88e24b1314c5d57d1a27b6d7448664ab7308ffaba640&"></img>
				</center>
			</div></div>
		]]
		local f = vgui.Create("DFrame")
		f:SetSize(ScrW()*0.8, ScrH()*0.8)
		f:SetTitle("Help Page")
		f:Center()
		f:MakePopup()
		local h = vgui.Create("DHTML", f)
		h:Dock(FILL)
		h:OpenURL("https://discord.gg/QkTBjdSPUn")
		return body
	end


end)