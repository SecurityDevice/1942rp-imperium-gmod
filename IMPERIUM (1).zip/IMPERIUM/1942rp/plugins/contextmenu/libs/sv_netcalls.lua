local netcalls = {"cmenu", "nutApproveSearch", "nutRequestSearch", "blindfold", "cmenu_tying", "cmenu_vehicle", "Dragging::Update", "FF", "moneyprompt", "nutRequestID", "nutApproveID"}

for k, v in pairs(netcalls) do
    util.AddNetworkString(v)
end

net.Receive("cmenu_tying", function()
    local entity = net.ReadEntity()
    netstream.Start(entity, "startcmenutying")
end)

net.Receive("cmenu", function()
    local entity = net.ReadEntity()
    netstream.Start(entity, "startcmenu")
end)

net.Receive("cmenu_vehicle", function()
    local entity = net.ReadEntity()
    netstream.Start(entity, "startcmenuvehicle")
end)