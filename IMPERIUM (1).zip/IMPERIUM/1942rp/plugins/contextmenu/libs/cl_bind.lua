local PLUGIN = PLUGIN

function PLUGIN:PlayerBindPress(ply, bind, down)
    local trace = {}
    trace.start = LocalPlayer():GetShootPos()
    trace.endpos = trace.start + LocalPlayer():GetAimVector() * 100
    trace.filter = LocalPlayer()
    local tr = util.TraceLine(trace)

    local target = tr.Entity
    if not target:IsPlayer() then return end
    if target == ply then return end

    -- Send this to the player if the person is tied.
	if down and string.find(bind, "+menu_context") then
        if target:IsRestricted() then
            if ply:GetActiveWeapon():GetClass() ~= "gmod_tool" then
                net.Start("cmenu_tying")
                    net.WriteEntity(LocalPlayer())
                net.SendToServer()
            elseif ply:GetActiveWeapon():GetClass() == "gmod_tool" then
                hook.Run("OnContextMenuOpen")

                return true
            end
        else
            -- Base context menu for players who are not tied.
            if ply:GetActiveWeapon():GetClass() ~= "gmod_tool" then
                net.Start("cmenu")
                    net.WriteEntity(LocalPlayer())
                net.SendToServer()
            elseif ply:GetActiveWeapon():GetClass() == "gmod_tool" then
                hook.Run("OnContextMenuOpen")

                return true
            end

            -- Assuming this code is within a function or hook.
            -- "ply" is the player who is interacting with the vehicle seat.
            -- "seat" is the seat entity the player is in.

            if IsValid(target) and target:IsVehicle() and ply:GetActiveWeapon():GetClass() ~= "gmod_tool" then
                net.Start("cmenu_vehicle")
                    net.WriteEntity(target)
                net.SendToServer()
            elseif ply:GetActiveWeapon():GetClass() == "gmod_tool" then
                hook.Run("OnContextMenuOpen")
                return true
            end
        end
    end

    if string.find(bind, "gm_showhelp") and IsValid(ply.nutRagdoll) then return true end
    if string.find(bind, "+speed") and ply:getNetVar("restricted") or (string.find(bind, "gm_showhelp") and ply:getNetVar("restricted")) or (string.find(bind, "+jump") and ply:getNetVar("restricted") and not IsValid(ply.nutRagdoll)) or (string.find(bind, "+walk") and ply:getNetVar("restricted")) or (string.find(bind, "+use") and ply:getNetVar("restricted")) then return true end
end

netstream.Hook("startcmenu", function()
    vgui.Create("cmenu")
end)

netstream.Hook("startcmenutying", function()
    vgui.Create("cmenu_tying")
end)

netstream.Hook("startcmenuvehicle", function()
    vgui.Create("cmenu_vehicle")
end)
