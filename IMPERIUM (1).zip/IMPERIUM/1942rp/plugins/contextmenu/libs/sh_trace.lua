local PLUGIN = PLUGIN

function PLUGIN:GetTrace(ply)
    local tr = util.TraceLine({
        start = ply:EyePos(),
        endpos = ply:EyePos() + (ply:GetAimVector() * 100),
        filter = ply
    })

    if IsValid(tr.Entity) and tr.Entity:IsPlayer() then
        local restricted = tr.Entity:getNetVar("restricted")
        if restricted then return tr, restricted end
    end
end
