PLUGIN.name = "Context Menu"
PLUGIN.author = "Leonheart, berko & rusty"
PLUGIN.desc = "Context menu used to interact with entities."

nut.util.include("cl_plugin.lua")
