local PANEL = {}

function PANEL:Init()
    self:MakePopup()
    self:Center()
    self:ToggleVisible(false)
    local menu = DermaMenu()

    local requestsearch = menu:AddOption("Request Search", function()
        LocalPlayer():ConCommand("say /requestsearch")
        self:Close()
    end)
    requestsearch:SetIcon( "icon16/magnifier.png" )

    local tieplayer = menu:AddOption("Tie Player", function()
        if LocalPlayer():getChar():getInv():hasItem("tie") then
            LocalPlayer():ConCommand("say /tieplayer")
            self:Close()
        end
    end)

    if not LocalPlayer():getChar():getInv():hasItem("tie") then
        tieplayer:Remove()
    end

    tieplayer:SetIcon("icon16/attach.png")

    local givemoney = menu:AddOption("Give Money", function()
        LocalPlayer():ConCommand("say /cmenugivemoney")
        self:Close()
    end)
    givemoney:SetIcon( "icon16/money_add.png" )

    local allowrecognition = menu:AddOption("Allow Recognition", function()
        netstream.Start("rgn", 1)
        self:Close()
    end)
    allowrecognition:SetIcon( "icon16/user_go.png" )

    menu:Open()
    menu:MakePopup()
    menu:Center()
end

vgui.Register("cmenu", PANEL, "DFrame")
