PLUGIN.name = "Active PK"
PLUGIN.author = "PKSystem"
PLUGIN.desc = "Active PK."

local characterMeta = nut.meta.character

nut.command.add("pkenable", {
	adminOnly = true,
	syntax = "<string name>",
	onRun = function(client, arguments)
		local target = nut.command.findPlayer(client, arguments[1])

		if (IsValid(target) && target:getChar()) then
			target:getChar():enablePK(target:getChar())
			client:notify("Setting "..(target:getChar():getName()).."\'s PK status to "..tostring(target:getChar():getData("pkCom")))
		end
	end
})

hook.Add("PlayerLoadedChar", "pkvarset", function(client, character)
	character:setData("pkCom", false, false, player.GetAll())
end)

if SERVER then

	function characterMeta:enablePK(char)
		if (char:getData("pkCom")) then
			char:setData("pkCom", false, false, player.GetAll())
		else
			char:setData("pkCom", true, false, player.GetAll())
		end
	end

	hook.Add("PlayerDeath", "pkCommand", function(victim, inflictor, attacker)
		local char = victim:getChar()

		if (victim:getChar() && victim:getChar():getData("pkCom")) then
			--if nut.config.get("deathTimer") then
			char:ban()
			victim:notify("You have been Permanently Killed!")
		end
	end)

end	