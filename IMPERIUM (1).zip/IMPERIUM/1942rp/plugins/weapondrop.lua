PLUGIN.name = "Drop Equipped Weapons"
PLUGIN.author = "-"
PLUGIN.desc = "When you die, you will lose any equipped weapons..."

function PLUGIN:PlayerDeath(client)
    local items = client:getChar():getInv():getItems()
    for k, item in pairs(items) do
        if item.isWeapon then
            if item:getData("equip") then
                item:remove()
                client:notify("You lost your equipped weapon due to dying.")
                
                client.lostWep = item
            end
        end
    end
end