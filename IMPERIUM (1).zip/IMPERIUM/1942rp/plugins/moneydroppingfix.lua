local commandCooldown = 300 -- 5 minutes

local maxCommandUses = 5

local commandUsageData = {}

nut.command.add("dropmoney", {
    syntax = "<number amount>",
    onRun = function(client, arguments)
        local cooldownExpiration = commandUsageData[client]
        if cooldownExpiration and CurTime() < cooldownExpiration then
            local remainingCooldown = math.ceil(cooldownExpiration - CurTime())
            return "@moneyCommandCooldown", remainingCooldown
        end

        commandUsageData[client] = (commandUsageData[client] or 0) + 1

        if commandUsageData[client] > maxCommandUses then
            commandUsageData[client] = CurTime() + commandCooldown

            return "@moneyCommandCooldown", commandCooldown
        end

        local amount = tonumber(arguments[1])

		if (not amount or not isnumber(amount) or amount < 5) then
			return "@invalidArg", 1
		end

		amount = math.Round(amount)

		if (not client:getChar():hasMoney(amount)) then
			return
		end

		client:getChar():takeMoney(amount)
		local money = nut.currency.spawn(client:getItemDropPos(), amount)
		money.client = client
		money.charID = client:getChar():getID()

		client:doGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE, true)

    end
})
