ITEM.name = "Dry House"
ITEM.desc = "Dry House"
ITEM.model = "models/customhq/tobaccofarm/dryhouse.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.entdrop = "tob_dryhouse"