ITEM.name = "Ash Tray"
ITEM.desc = "Ash Tray"
ITEM.model = "models/customhq/tobaccofarm/ashtray.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.entdrop = "tob_ashtrey"