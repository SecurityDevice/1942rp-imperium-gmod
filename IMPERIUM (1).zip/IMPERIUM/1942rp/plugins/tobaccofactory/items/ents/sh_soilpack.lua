ITEM.name = "Soil Pack"
ITEM.desc = "Soil Pack"
ITEM.model = "models/customhq/tobaccofarm/sack.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.entdrop = "tob_dirt"