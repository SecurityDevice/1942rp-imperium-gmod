ITEM.name = "Pot"
ITEM.desc = "Pot"
ITEM.model = "models/customhq/tobaccofarm/pot.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.entdrop = "tob_plant"