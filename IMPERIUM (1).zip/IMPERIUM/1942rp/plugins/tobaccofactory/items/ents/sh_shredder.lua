ITEM.name = "Shredder"
ITEM.desc = "Shredder"
ITEM.model = "models/customhq/tobaccofarm/shredder.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.entdrop = "tob_shredder"