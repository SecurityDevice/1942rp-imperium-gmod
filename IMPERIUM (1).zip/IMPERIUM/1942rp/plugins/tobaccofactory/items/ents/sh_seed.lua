ITEM.name = "Seed"
ITEM.desc = "Seed"
ITEM.model = "models/customhq/tobaccofarm/box.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.entdrop = "tob_seed"