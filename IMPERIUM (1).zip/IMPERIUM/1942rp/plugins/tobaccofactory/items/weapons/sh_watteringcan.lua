ITEM.name = "Watering Can"
ITEM.desc = "Watering Can"
ITEM.model = "models/craphead_scripts/ch_farming/weapons/w_wateringcan.mdl"
ITEM.class = "ch_farming_water_can"
