local PLUGIN = PLUGIN
PLUGIN.name = "Tobacco Factory"
PLUGIN.author = "Barata"
PLUGIN.desc = "Tobacco Factory ported to NS."
