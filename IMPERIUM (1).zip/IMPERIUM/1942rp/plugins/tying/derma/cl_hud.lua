local PLUGIN = PLUGIN

function PLUGIN:RenderScreenspaceEffects()
    local ply = LocalPlayer()
    if not (ply:IsRestricted() and ply:IsBlinded()) then return end
    surface.SetDrawColor(Color(0, 0, 0, 254))
    surface.DrawRect(0, 0, ScrW(), ScrH())
end
