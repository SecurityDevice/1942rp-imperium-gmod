local playerMeta = FindMetaTable("Player")

function playerMeta:IsRestricted()
    if self:getNetVar("restricted", false) then return true end

    return false
end

function playerMeta:IsVehicleAllowed()
    if self:getNetVar("vehicle_allowed", false) then return true end

    return false
end

function playerMeta:IsDragged()
    if self:getNetVar("dragged", false) then return true end

    return false
end

function playerMeta:IsBlinded()
    if self:getNetVar("blinded", false) then return true end

    return false
end

function playerMeta:GetCanBlind(ply)
    if self ~= ply or false then return true end

    return false
end

function playerMeta:GetCanGag(ply)
    if self ~= ply or false then return true end

    return false
end
