local PLUGIN = PLUGIN

nut.command.add("admincharbanksearch", {
    onRun = function(client, arguments)
        local target = nut.command.findPlayer(client, arguments[1])
        if not client:getChar() or not client:getChar():getInv() then return false end
        if not IsValid(target) or not target:IsPlayer() then return false, "@invalidPly" end
        if not target:HasBankAccount() then return false, "Player has no bank account!" end
        local char = target:getChar()
        local ibInvID = char:getData("itemBankInvID")
        local inventorySize = "default"

        if not ibInvID then
            client:notify("Player has no Bank!")
        else
            local inventory = nut.inventory.instances[ibInvID]
            local w, h = inventory:getSize()
            inventory.isBank = true
            inventory:setSize(10, 10)
            inventory:sync(client)
            netstream.Start(client, "OpenItemBank", ibInvID)
        end
    end
})

nut.command.add("charbanksearch", {
    onRun = function(client, arguments)
        local data = {}
        data.start = client:GetShootPos()
        data.endpos = data.start + client:GetAimVector() * 96
        data.filter = client
        local target = util.TraceLine(data).Entity

        if not target:IsPlayer() then
            client:notify("Invalid Target!")

            return
        end

        if not target:IsRestricted() then
            client:notify("The person needs to be restrained!")

            return
        end

        if not client:getChar() or not client:getChar():getInv() then return false end
        if not IsValid(target) or not target:IsPlayer() then return false, "@invalidPly" end
        local MAXDISTANCE_TARGET = 100 * 100 -- SQUARED FOR PERFORMANCE The distance the dragged player will try to achieve
        local TargetPos = target:GetPos()
        local myPos = client:GetPos()
        local dist2Sqr = (TargetPos.x - myPos.x) ^ 2 + (TargetPos.y - myPos.y) ^ 2

        if target:IsRestricted() then
            if dist2Sqr < MAXDISTANCE_TARGET then
                if target:getNetVar("restricted") then
                    if not target:HasBankAccount() then return false, "Player has no bank account!" end
                    local char = target:getChar()
                    local ibInvID = char:getData("itemBankInvID")
                    local inventorySize = "default"

                    if not ibInvID then
                        client:notify("Player has no Bank!")
                    else
                        local inventory = nut.inventory.instances[ibInvID]
                        local w, h = inventory:getSize()
                        inventory.isBank = true
                        inventory:setSize(10, 10)
                        inventory:sync(client)
                        netstream.Start(client, "OpenItemBank", ibInvID)
                    end
                else
                    return false, "@This player must be tied"
                end
            else
                client:notify("You can't use this from distance!")

                return
            end
        else
            client:ChatPrint("This person isn't restrained!")
        end
    end
})

nut.command.add("blindplayer", {
    onRun = function(client, arguments)
        local data = {}
        data.start = client:GetShootPos()
        data.endpos = data.start + client:GetAimVector() * 96
        data.filter = client
        local target = util.TraceLine(data).Entity

        if not target:IsPlayer() then
            client:notify("Invalid Target!")

            return
        end

        if not target:IsRestricted() then
            client:notify("The person needs to be restrained!")

            return
        end

        local MAXDISTANCE_TARGET = 100 * 100 -- SQUARED FOR PERFORMANCE The distance the dragged player will try to achieve
        local TargetPos = target:GetPos()
        local myPos = client:GetPos()
        local dist2Sqr = (TargetPos.x - myPos.x) ^ 2 + (TargetPos.y - myPos.y) ^ 2

        if dist2Sqr < MAXDISTANCE_TARGET then
            if target:IsBlinded() then
                target:SetBlinded()
                client:EmitSound("npc/combine_soldier/gear3.wav", 100, 100)
                client:setAction("Taking blindfold off...", 1.5)
                target:setAction("You feel something on your face...", 1.5)
                client:DoAnimationEvent(ACT_GMOD_GESTURE_MELEE_SHOVE_1HAND)

                timer.Simple(1.5, function()
                    client:ConCommand("say /me takes off a black blindfold from the tied person's face.")
                    client:EmitSound("npc/combine_soldier/gear4.wav", 100, 100)
                end)
            else
                target:SetBlinded()
                client:EmitSound("npc/combine_soldier/gear5.wav", 100, 100)
                client:setAction("Putting blindfold on...", 1.5)
                client:DoAnimationEvent(ACT_GMOD_GESTURE_MELEE_SHOVE_1HAND)

                timer.Simple(1.5, function()
                    client:ConCommand("say /me puts a black blindfold onto the tied person's face.")
                    client:EmitSound("npc/combine_soldier/gear4.wav", 100, 100)
                end)
            end
        else

            client:notify("You can't use this from distance!")

            return
        end
    end
})

nut.command.add("dragplayer", {
    onRun = function(client, arguments)
        local tr = util.TraceLine(util.GetPlayerTrace(client))
        local target = tr.Entity
        if client:InVehicle() or IsBeingDragged(client) then return end

        if IsValid(target) and target:IsPlayer() and target:GetPos():DistToSqr(client:GetPos()) <= DRAGGING_START_RANGE * DRAGGING_START_RANGE and target:getNetVar("restricted") and not target:InVehicle() then
            if target:IsDragged() then
                SetDrag(nil, client)
                SetDrag(target, nil)
                target:setNetVar("dragged", false)
            elseif not target:IsDragged() then
                SetDrag(target, client)
                target:setNetVar("dragged", true)
            end
        else
            client:notify("Invalid Target!")
        end
    end
})

nut.command.add("setrestricted", {
    syntax = "<string target>",
    onRun = function(client, arguments)
        local target = nut.command.findPlayer(client, arguments[1])

        if not IsValid(target) then
            client:notify("Invalid target player.")

            return false
        end

        local uniqueID = client:GetUserGroup()

        if not UserGroups.staff[uniqueID] then
            client:notify("Your rank is not high enough to use this command.")

            return false
        end

        target:SetRestricted(true)
    end
})

nut.command.add("setblinded", {
    onRun = function(client, arguments)
        local target = nut.command.findPlayer(client, arguments[1])
        local uniqueID = client:GetUserGroup()

        if not UserGroups.staff[uniqueID] then
            client:notify("Your rank is not high enough to use this command.")

            return false
        end

        if not IsValid(target) then
            client:notify("This player isn't restrained!")

            return false
        end

        target:SetBlinded(true) 
    end
})

nut.command.add("charsearch", {
    onRun = function(client, arguments)
        local data = {}
        data.start = client:GetShootPos()
        data.endpos = data.start + client:GetAimVector() * 96
        data.filter = client
        local target = util.TraceLine(data).Entity

        if not target:IsPlayer() then
            client:notify("Invalid Target!")

            return
        end

        if not target:IsRestricted() then
            client:notify("The person needs to be restrained!")

            return
        end

        if not client:getChar() or not client:getChar():getInv() then return false end
        if not IsValid(target) or not target:IsPlayer() then return false, "@invalidPly" end
        local MAXDISTANCE_TARGET = 100 * 100 -- SQUARED FOR PERFORMANCE The distance the dragged player will try to achieve
        local TargetPos = target:GetPos()
        local myPos = client:GetPos()
        local dist2Sqr = (TargetPos.x - myPos.x) ^ 2 + (TargetPos.y - myPos.y) ^ 2

        if target:IsRestricted() then
            if dist2Sqr < MAXDISTANCE_TARGET then
                if target:getNetVar("restricted") then
                    client:EmitSound("npc/combine_soldier/gear5.wav", 100, 100)
                    client:setAction("Reaching into pockets...", 2)
                    target:setAction("You feel something in your pockets...", 2)
                    client:DoAnimationEvent(ACT_GMOD_GESTURE_ITEM_PLACE)

                    timer.Simple(2, function()
                        PLUGIN:searchPlayer(client, target)
                        client:ConCommand("say /me reaches into tied persons pockets.")
                        client:EmitSound("npc/combine_soldier/gear4.wav", 100, 100)
                    end)
                else
                    return false, "@This player must be tied"
                end
            else
                client:notify("You can't use this from distance!")

                return
            end
        else
            client:notify("This character isn't restrained!")
        end
    end
})

nut.command.add("admincharsearch", {
    syntax = "",
    onRun = function(client, arguments)
        local uniqueID = client:GetUserGroup()

        if not UserGroups.staff[uniqueID] then
            client:notify("Your rank is not high enough to use this command.")

            return false
        end

        local target = nut.command.findPlayer(client, arguments[1])

        if IsValid(target) and target:IsPlayer() then
            PLUGIN:searchPlayer(client, target)
        end
    end
})
