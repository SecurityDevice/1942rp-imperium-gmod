local playerMeta = FindMetaTable("Player")

function playerMeta:SetVehicleAllowed()
    if self:getNetVar("vehicle_allowed") then
        self:setNetVar("vehicle_allowed", false)
    else
        self:setNetVar("vehicle_allowed", true)
    end
end

function playerMeta:FreeTies()
    self:setNetVar("vehicle_allowed", false)
    self:setNetVar("blinded", false)
    self:setNetVar("dragged", false)

    self:setNetVar("restricted", false)
end

function playerMeta:SetBlinded()
    if self:getNetVar("blinded") then
        self:setNetVar("blinded", false)
    else
        self:setNetVar("blinded", true)
    end
end

function playerMeta:SetRestricted()
    if self:getNetVar("restricted") then
        self:setNetVar("restricted", false)
    else
        self:setNetVar("restricted", true)
    end
end

function playerMeta:setRestrictedTying(state, noMessage)
    if state then
        self:SetWalkSpeed(nut.config.get("walkSpeed", 130) * 0.5)
        self:SetRunSpeed(nut.config.get("runSpeed", 235) * 0.5)
        self:setNetVar("restricted", true)

        if noMessage then
            self:setLocalVar("restrictNoMsg", true)
        end

        self.nutRestrictWeps = self.nutRestrictWeps or {}

        for k, v in ipairs(self:GetWeapons()) do
            self.nutRestrictWeps[k] = v:GetClass()
        end

        timer.Simple(0, function()
            self:StripWeapons()
        end)

        hook.Run("OnPlayerRestricted", self)
    else
        self:setNetVar("restricted")
        self:SetWalkSpeed(nut.config.get("walkSpeed", 130))
        self:SetRunSpeed(nut.config.get("runSpeed", 235))

        if self:getLocalVar("restrictNoMsg") then
            self:setLocalVar("restrictNoMsg")
        end

        if self.nutRestrictWeps then
            for k, v in ipairs(self.nutRestrictWeps) do
                self:Give(v)
            end

            self.nutRestrictWeps = nil
        end

        hook.Run("OnPlayerUnRestricted", self)
    end
end
