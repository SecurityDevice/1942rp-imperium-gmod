local PLUGIN = PLUGIN

function PLUGIN:OnPlayerUnRestricted(client)
    local searcher = client:getNetVar("searcher")

    if IsValid(searcher) then
        self:stopSearching(searcher)
    end
end

function PLUGIN:PlayerSpawn(ply)
    if not ply:getChar() then return end
    ply:FreeTies()
end

local function nutApproveSearch(len, ply)
    local requester = ply.SearchRequested
    if not requester then return end
    if not requester.SearchRequested then return end
    local approveSearch = net.ReadBool()

    if not approveSearch then
        requester:notify("Player denied your request to view their inventory.")
        requester.SearchRequested = nil
        ply.SearchRequested = nil

        return
    end

    if requester:GetPos():DistToSqr(ply:GetPos()) > 250 * 250 then return end
    PLUGIN:searchPlayer(requester, ply, true)
    requester.SearchRequested = nil
    ply.SearchRequested = nil
end

net.Receive("nutApproveSearch", nutApproveSearch)
