PLUGIN.CommunityName = "Imperium"
PLUGIN.ChatMessagesInterval = 300
PLUGIN.ChatMessages = {"You can find the game content by using the /content command!", "You can join our server by using the /discord command!", "If you need staff send them a message @ message!",}