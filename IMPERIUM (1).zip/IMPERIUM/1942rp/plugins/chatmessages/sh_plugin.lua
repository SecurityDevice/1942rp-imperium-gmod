PLUGIN.name = "Chat Messages"
PLUGIN.author = "76561198312513285"
PLUGIN.desc = "Adds Simple Adverts."
nut.util.include("sh_config.lua")
nut.util.include("cl_plugin.lua")