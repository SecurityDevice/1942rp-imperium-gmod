PLUGIN.name = "ADV Dupe Restriction"
PLUGIN.desc = ""
PLUGIN.author = ""

nut.flag.add("A", "Access to the adv dupe")

hook.Add( "CanTool", "advduperestrict", function(ply,  trace, tool)
  local char = ply:getChar()
  if tool == "advdupe2" and not char:getFlags():find("d") then
    return false
  end
end )

nut.flag.add("D", "Access to the duplicator")

hook.Add( "CanTool", "diplicatorrestrict", function(ply,  trace, tool)
  local char = ply:getChar()
  if tool == "duplicator" and not char:getFlags():find("1") then
    return false
  end
end )
