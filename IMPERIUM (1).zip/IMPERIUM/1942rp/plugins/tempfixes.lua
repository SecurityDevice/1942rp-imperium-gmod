PLUGIN.name = "Discord"
PLUGIN.author = ""
PLUGIN.desc = ""

-- Community Related Commands

nut.command.add("setrank", {
    syntax = "",
    onRun = function(client, arguments)
        print("Some complete retard tried using setrank, go fuck yourself")
    end
})

nut.command.add("setrankid", {
    syntax = "",
    onRun = function(client, arguments)
        print("Some complete retard tried using setrankid, go fuck yourself")
    end
})