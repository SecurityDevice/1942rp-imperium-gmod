--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/sh_cigarette.lua
Size: 842 B

]===]
ITEM.name = "Cigarette"
ITEM.desc = "A narrow cylinder containing tobacco, rolled into thin paper for smoking."
--ITEM.model = "models/jellik/cigarette.mdl"
ITEM.model = "models/mordeciga/mordes/oldcigshib.mdl"
ITEM.uniqueid = "cigarette"
ITEM.category = "Drugs"

ITEM.functions.TakeOutCig = {
	name = "Light Up & Smoke",
	onRun = function(item)
		local client = item.player
		nut.chat.send(client, "me", "takes out a cigarette and lights it up.")
		client:Give("weapon_ciga")
		client:SelectWeapon("weapon_ciga")
		timer.Create("Cig_" ..client:UniqueID(), 2, 0, function()
			if (client:GetActiveWeapon():GetClass() != "weapon_ciga") then
				client:StripWeapon("weapon_ciga")
				nut.chat.send(client, "me", "finishes cigarette and stomps it out.")
				timer.Remove("Cig_" ..client:UniqueID())
			end
		end)
	end
}

