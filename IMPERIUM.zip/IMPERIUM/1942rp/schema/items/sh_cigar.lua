--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/sh_cigar.lua
Size: 784 B

]===]
ITEM.name = "Cigar"
ITEM.desc = "A rolled bundle of dried and fermented tobacco leaves made to be smoked."
ITEM.model = "models/jellik/cigar.mdl"
ITEM.price = 2500
ITEM.category = "Drugs"

ITEM.functions.TakeOutCigar = {
	name = "Light Up & Smoke",
	onRun = function(item)
		local client = item.player
		nut.chat.send(client, "me", "takes out a cigar and lights it up.")
		client:Give("weapon_ciga_blat")
		client:SelectWeapon("weapon_ciga_blat")
		timer.Create("Cigar_" ..client:UniqueID(), 2, 0, function()
			if (client:GetActiveWeapon():GetClass() != "weapon_ciga_blat") then
				client:StripWeapon("weapon_ciga_blat")
				nut.chat.send(client, "me", "finishes cigar and stomps it out.")
				timer.Remove("Cigar_" ..client:UniqueID())
			end
		end)
	end
}

