--[===[
 _    _______  ___  _____ _____ _   _   _____ _   _
| |  | | ___ \/ _ \|_   _|_   _| | | | /  ___| | | |
| |  | | |_/ / /_\ \ | |   | | | |_| | \ `--.| | | |
| |/\| |    /|  _  | | |   | | |  _  |  `--. \ | | |
\  /\  / |\ \| | | |_| |_  | | | | | |_/\__/ / |_| |
 \/  \/\_| \_\_| |_/\___/  \_/ \_| |_(_)____/ \___/


Files stolen by https://wraith.su - Premium Garry's Mod Cheat

Server Name : PrometheusNetworks.gg█Imperial Germany - Berlin█NEW MAP
Server IP : 193.243.190.50:27015

File: gamemodes/1942rp/schema/items/medical/sh_ivbag.lua
Size: 431 B

]===]
ITEM.name = "IV Bag"
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.material = "models/props/cs_assault/moneywrap02"
ITEM.width = 1
ITEM.height = 1
ITEM.healAmount = 50
ITEM.healSeconds = 1
ITEM.price = 10
ITEM.desc = "A small bag that can be used for IV therapy."
ITEM.uniqueID = "medical_iv"
ITEM.permit = "permit_med"

ITEM.iconCam = {
	pos = Vector(0, 0, 200),
	ang = Angle(90, 0, 170),
	fov = 5.5,
}