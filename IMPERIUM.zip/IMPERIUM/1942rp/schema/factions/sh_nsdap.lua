FACTION.name = "Politischer Leiter der NSDAP"
FACTION.desc = "Politischer Leiter der NSDAP" 
FACTION.color = Color(127, 201, 255)
FACTION.isGloballyRecognized = false
FACTION.isDefault = false

FACTION_NSDAP = FACTION.index