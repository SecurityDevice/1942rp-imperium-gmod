FACTION.name = "Wehrkreis-III"

FACTION.desc = "WK"

FACTION.color = Color(127, 201, 255)

FACTION.isGloballyRecognized = false

FACTION.isDefault = false

FACTION_HEER = FACTION.index
