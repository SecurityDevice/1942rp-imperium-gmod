FACTION.name = "Oberkommando des Marine"

FACTION.desc = "OKM"

FACTION.color = Color(127, 201, 255)

FACTION.isGloballyRecognized = false

FACTION.isDefault = false

FACTION_OKM = FACTION.index