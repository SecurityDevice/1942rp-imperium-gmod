FACTION.name = "Staff on Duty"
FACTION.desc = "Staff on Duty"
FACTION.color = Color(127, 201, 255)
FACTION.isGloballyRecognized = true
FACTION.isDefault = false
FACTION.weapons = {"adminstick", "gmod_tool", "weapon_physgun"}

FACTION_STAFF = FACTION.index

FACTION.index = FACTION_STAFF