PLUGIN.name = "Banking"

PLUGIN.author = "Logan"

PLUGIN.desc = "Spear Networks"