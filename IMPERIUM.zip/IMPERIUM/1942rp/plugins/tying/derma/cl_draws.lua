local PLUGIN = PLUGIN
local ForceJump = {}

function PLUGIN:Think()
    for ply, v in pairs(ForceJump) do
        if not (IsValid(ply) and ply:OnGround()) then
            ForceJump[ply] = nil

            return
        end

        local tr = util.TraceLine({
            start = ply:GetPos(),
            endpos = ply:GetPos() + Vector(0, 0, 20),
            filter = ply
        })

        if tr.Hit then return end
        ply:SetPos(ply:GetPos() + Vector(0, 0, 5))
        ForceJump[ply] = nil
    end
end

local HeadBone = "ValveBiped.Bip01_Head1"
local DefaultRope = Material("cable/rope")

local RenderPos = {
    Blind = {Vector(3.5, 3, 2.6), Vector(3.8, 4.8, 0), Vector(3.5, 3, -2.8), Vector(2.4, -2, -3.8), Vector(1.5, -4.5, 0), Vector(2.4, -2, 3.8)},
}

function PLUGIN:PostPlayerDraw(ply)
    if not IsValid(ply) or not ply:IsRestricted() then return end
    render.SetMaterial(DefaultRope)

    if ply:IsBlinded() then
        local pos, ang
        local bone = ply:LookupBone(HeadBone)

        if bone then
            pos, ang = ply:GetBonePosition(bone)
        end

        if pos and ang then
            local firstpos = pos + (ang:Forward() * RenderPos.Blind[1].x) + (ang:Right() * RenderPos.Blind[1].y) + (ang:Up() * RenderPos.Blind[1].z)
            local lastpos = firstpos

            for i = 2, #RenderPos.Blind do
                local newPos = pos + (ang:Forward() * RenderPos.Blind[i].x) + (ang:Right() * RenderPos.Blind[i].y) + (ang:Up() * RenderPos.Blind[i].z)
                render.DrawBeam(newPos, lastpos, 1.5, 0, 1, Color(255, 255, 255))
                lastpos = newPos
            end

            render.DrawBeam(lastpos, firstpos, 1.5, 0, 1, Color(255, 255, 255))
        end
    end
end
