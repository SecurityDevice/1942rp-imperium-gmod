nut.command.add("admincharbanksearch", {
    onRun = function(client, arguments) end
})

nut.command.add("charbanksearch", {
    onRun = function(client, arguments) end
})

nut.command.add("blindplayer", {
    onRun = function(client, arguments) end
})

nut.command.add("tieplayer", {
    onRun = function(client, arguments) end
})

nut.command.add("dragplayer", {
    onRun = function(client, arguments) end
})

nut.command.add("setrestricted", {
    onRun = function(client, arguments) end
})

nut.command.add("setblinded", {
    onRun = function(client, arguments) end
})

nut.command.add("charsearch", {
    onRun = function(client, arguments) end
})

nut.command.add("admincharsearch", {
    syntax = "<string target>",
    onRun = function(client, arguments) end
})
