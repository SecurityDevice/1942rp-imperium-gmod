PLUGIN.name = "Bodygroup Closet"
PLUGIN.author = ""
PLUGIN.desc = "Adds a bodygroup closet."
nut.util.include("sv_hooks.lua")
nut.util.include("cl_hooks.lua")
