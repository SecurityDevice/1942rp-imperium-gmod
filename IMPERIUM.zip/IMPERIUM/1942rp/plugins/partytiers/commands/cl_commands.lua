--------------------------------------------------------------------------------------------------------
nut.command.add(
    "partytier",
    {
        adminOnly = false,
        privilege = "Management - Assign Party Tiers",
        syntax = "<string name> <string number>",
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------