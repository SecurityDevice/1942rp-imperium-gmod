local staffMafiaHigh = {
	superadmin = true,
	globaladministration = true,
	upperadministration = true,
	serverstaff = true,
	gamemasterteam = true,
}

nut.command.add("charlist", {
    syntax = "<string playerORsteamID>",
    onRun = function(client, arguments)

        local uniqueID = client:GetUserGroup()
		if(!staffMafiaHigh[uniqueID]) then
			client:notify("Your rank is not defined within a set table!")
			return false
		end

        local targetSteamID
        if not client:IsSuperAdmin() then return "This command is only available to Admin+" end

        if arguments[1] then
            local target = nut.command.findPlayerSilent(table.concat(arguments, ' ', 1))

            if IsValid(target) then
                targetSteamID = target:SteamID64()
            else
                if arguments[1]:sub(1, 6) ~= "STEAM_" then return "Invalid argument (#1)" end
                targetSteamID = util.SteamIDTo64(arguments[1])
                if not targetSteamID or targetSteamID == 0 then return "Invalid argument (#1)" end
            end
        else
            targetSteamID = client:SteamID64()
        end

        if not targetSteamID then return "Invalid argument (#1)" end
        if not tonumber(targetSteamID) then return "Something went wrong - Contact Dev" end
        local targetSteamIDsafe = targetSteamID
        local q = sql.Query("SELECT * FROM nut_characters WHERE _steamID=" .. targetSteamIDsafe)
        if q == false then return "Query error - Contact developer" end
        local properData = {}
        local sendData = {}

        for k, v in pairs(q or {}) do
            local loaded = nut.char.loaded[v._id]
            local useData = loaded and loaded:getData() or v._data

            if type(useData) == "string" then
                useData = util.JSONToTable(useData) or {}
            end

            if not useData then return "Weird error - Contact developer" end
            local sendChar = {}
            sendChar.ID = v._id
            sendChar.Name = v._name
            sendChar.Desc = v._desc
            sendChar.Faction = v._faction
            sendChar.Banned = useData.banned and "Yes" or "No"
            sendChar.BanningAdminName = useData.charBanInfo and useData.charBanInfo.name or ""
            sendChar.BanningAdminSteamID = useData.charBanInfo and useData.charBanInfo.steamID or ""
            sendChar.BanningAdminRank = useData.charBanInfo and useData.charBanInfo.rank or ""
            table.insert(sendData, sendChar)
        end

        netstream.Start(client, "DisplayCharList", sendData, targetSteamIDsafe)
    end
})