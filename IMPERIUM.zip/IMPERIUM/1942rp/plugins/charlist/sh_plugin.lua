PLUGIN.name = "Character List"
PLUGIN.desc = "Adds a Character Listing System."
PLUGIN.author = "Leonheart#7476"
nut.util.include("cl_plugin.lua")
nut.util.include("sv_plugin.lua")
nut.util.include("sh_hooks.lua")