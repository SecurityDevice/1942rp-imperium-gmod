ITEM.name = "Cigarette Machine"
ITEM.desc = "A machine that produces cigarettes."
ITEM.model = "models/cigarette_factory/cf_machine.mdl"
ITEM.noDrop = true

ITEM.functions.Place = {
	name = "Place",
	onRun = function(item)
		local client = item.player

		local ent = ents.Create("cf_cigarette_machine")
		if (!ent) then
			client:notify("Failed to place.")
			return
		end

		local startpos = client:EyePos()
		local mins = ent:OBBMins()
		local maxs = ent:OBBMaxs()
		local traceResult = util.TraceHull({
			start = startpos,
			endpos = startpos + 150*client:EyeAngles():Forward(),
			mins = mins,
			maxs = maxs,
			filter = client
		})

		if (traceResult.Fraction < 0.25) then
			client:notify("There isn't enough space here.")
			ent:Remove()
			return
		end

		local zOffset = (mins.z > maxs.z) and mins.z or maxs.z
		ent:SetPos(traceResult.HitPos + Vector(0, 0, zOffset))
		ent:Spawn()

		-- Update data post-spawn (because Initialize resets it anyway)
		local tobaccoAmount = item:getData("tobaccoAmount", 0)
		if (tobaccoAmount != 0) then
			ent.tobaccoAmount = tobaccoAmount
		end
		local paperAmount = item:getData("paperAmount", 0)
		if (paperAmount != 0) then
			ent.paperAmount = paperAmount
		end
		local storageUpgrade = item:getData("storageUpgrade", false)
		if (storageUpgrade) then
			ent.storageUpgrade = storageUpgrade
		end
		local engineUpgrade = item:getData("engineUpgrade", false)
		if (engineUpgrade) then
			ent.engineUpgrade = engineUpgrade
		end
	end
}

ITEM.functions.Drop = nil