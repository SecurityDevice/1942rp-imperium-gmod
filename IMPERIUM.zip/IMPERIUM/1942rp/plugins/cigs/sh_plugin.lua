PLUGIN.name = "Ciggerattes"
PLUGIN.desc = "Spare a cig?"
PLUGIN.author = "It's A Joke"
