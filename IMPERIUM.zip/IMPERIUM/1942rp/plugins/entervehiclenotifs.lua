if (SERVER) then
    local allowedVehicles = { // such a shit fix, shit sit addon.
        ["sim_fphys_dukes"] = true,
        ["simfphys_mafia2_trautenberg_grande"] = true,
        ["simfphys_mafia2_ulver_newyorker"] = true,
        ["simfphys_mafia2_ulver_newyorker_p"] = true,
        ["simfphys_mafia2_gai_353_military_truck"] = true,
        ["simfphys_mafia2_sicily_military_truck"] = true,
        ["simfphys_mafia2_JefProv"] = true,
        ["simfphys_mafia2_lassiter_69"] = true,
        ["simfphys_mafia2_parry_bus"] = true,
        ["simfphys_mafia2_parry_prison"] = true,
        ["simfphys_mafia2_shubert_38"] = true,
        ["simfphys_mafia2_shubert_hearse"] = true,
        ["simfphys_mafia2_shubert_panel"] = true,
        ["simfphys_mafia2_shubert_taxi"] = true,
        ["simfphys_mafia2_shubert_pickup"] = true,
        ["simfphys_mafia2_shubert_34"] = true,
        ["simfphys_mafia2_Shubert_Truck_SP"] = true,
        ["simfphys_mafia2_shubert_truck_cc"] = true,
        ["simfphys_mafia2_shubert_truck_qd"] = true,
        ["simfphys_mafia2_shubert_truck_ct"] = true,
        ["simfphys_mafia2_smith_coupe"] = true,
        ["simfphys_mafia2_smith_truck"] = true,
        ["simfphys_mafia2_smith_v8"] = true,
        ["simfphys_mafia2_walter_coupe"] = true,
        ["simfphys_mafia2_jeep"] = true,
        ["simfphys_mafia2_jeep_civil"] = true,
        ["simfphys_mafia2_ascba"] = true,
        ["simfphys_mafia2_bkingf"] = true,
        ["simfphys_mafia2_shubert_chaffeque"] = true,
        ["simfphys_mafia2_delizia_grandeamerica"] = true,
        ["simfphys_mafia2_hank_b"] = true,
        ["simfphys_mafia2_hank_fueltank"] = true,
        ["simfphys_mafia2_Hwasp"] = true,
        ["simfphys_mafia2_isw_508"] = true,
        ["simfphys_mafia2_Jeffut"] = true,
        ["simfphys_mafia2_Lass75"] = true,
        ["simfphys_mafia2_milk_truck"] = true,
        ["simfphys_mafia2_shubert_elysium"] = true,
        ["simfphys_mafia2_potomac_indian"] = true,
        ["simfphys_mafia2_quicksilver_windsor_pha"] = true,
        ["simfphys_mafia2_quicksilver_windsor_taxi_pha"] = true,
        ["simfphys_mafia2_roller"] = true,
        ["simfphys_mafia2_shubert_armoured"] = true,
        ["simfphys_mafia2_shubert_beverly"] = true,
        ["simfphys_mafia2_shubert_frigate_pha"] = true,
        ["simfphys_mafia2_hot_rod_3"] = true,
        ["simfphys_mafia2_hot_rod_2"] = true,
        ["simfphys_mafia2_smith_200_pha"] = true,
        ["simfphys_mafia2_smith_200_p_pha"] = true,
        ["simfphys_mafia2_smith_wagon_pha"] = true,
        ["simfphys_mafia2_smith_mainline_pha"] = true,
        ["simfphys_mafia2_smith_stingray_pha"] = true,
        ["simfphys_mafia2_walker_rocket"] = true,
        ["simfphys_mafia2_hot_rod_1"] = true,
        ["simfphys_mafia2_waybar"] = true,
    }

    local lastMeTime = {}

    hook.Add("PlayerEnteredVehicle", "simfphys_EnterLeaveChat", function(ply, vehicle, role)
        local vehicleName = vehicle:GetVehicleClass()

        if allowedVehicles[vehicleName] then
            if CanSendMeMessage(ply) then
                nut.chat.send(ply, "me", "enters the vehicle.")
            else
                ply:ChatPrint("You've reached the /me message limit. Please wait.")
            end
        end
    end)

    hook.Add("PlayerLeaveVehicle", "simfphys_EnterLeaveChat", function(ply, vehicle)
        local vehicleName = vehicle:GetVehicleClass()

        if allowedVehicles[vehicleName] then
            if CanSendMeMessage(ply) then
                nut.chat.send(ply, "me", "leaves the vehicle.")
            else
                ply:ChatPrint("You've reached the /me message limit. Please wait.")
            end
        end
    end)

    function CanSendMeMessage(ply)
        local steamID = ply:SteamID()
        local currentTime = CurTime()

        lastMeTime[steamID] = lastMeTime[steamID] or 0

        if lastMeTime[steamID] + 60 <= currentTime then
            lastMeTime[steamID] = currentTime
            ply.meMessageCount = 1
        elseif ply.meMessageCount and ply.meMessageCount >= 5 then
            return false
        else
            ply.meMessageCount = (ply.meMessageCount or 0) + 1
        end

        return true
    end
end
