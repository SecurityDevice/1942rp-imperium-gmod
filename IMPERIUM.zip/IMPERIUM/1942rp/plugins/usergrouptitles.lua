local PLUGIN = PLUGIN
PLUGIN.name = "Admin Drawing"
PLUGIN.author = "CallowayIsWeird"
PLUGIN.desc = "Shows above the head if they are an admin or not using usergroups."
 
if (CLIENT) then
    local SUPERADMIN = Color(255, 209, 20)
    local GLOBALADMINISTRATION = Color(255, 209, 20)
    local UPPERADMINISTRATION = Color(255, 209, 20)
    local SERVERSTAFF = Color(255, 209, 20)
    local GAMEMASTERTEAM = Color(4, 251, 255)

    hook.Add( "DrawCharInfo", "DrawCharInfoStaff", function( client, character, info )
        if (client:Team() == FACTION_STAFF) then

         

            if (client:IsUserGroup("superadmin")) then
                info[#info + 1] = {"Superadmin", SUPERADMIN}
            end

            if (client:IsUserGroup("globaladministration")) then
                info[#info + 1] = {"globaladministration", GLOBALADMINISTRATION}
            end

            if (client:IsUserGroup("upperadministration")) then
                info[#info + 1] = {"upperadministration", UPPERADMINISTRATION}
            end

            if (client:IsUserGroup("serverstaff")) then
                info[#info + 1] = {"serverstaff", SERVERSTAFF}
            end

            if (client:IsUserGroup("gamemasterteam")) then
                info[#info + 1] = {"gamemasterteam", GAMEMASTERTEAM}
            end
        end
    end )
end