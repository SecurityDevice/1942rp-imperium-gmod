-- oink.industries
-- lua source: gamemodes/1942rp/plugins/talks/languages/sh_english.lua
NAME = "English"

LANGUAGE = {
	talkGive = "%s has given %s to %s.",
	talkTake = "%s has taken %s away from %s."
}
