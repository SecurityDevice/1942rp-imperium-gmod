ITEM.name = "Cassette Base"
ITEM.model = "models/comradebear/props/codww2/zmb/record_01.mdl"
ITEM.music = "https://www.marxists.org/history/ussr/sounds/mp3/proletariat-01/Varshavjanka.mp3"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "This is a Shellac."
ITEM.category = "Technology"