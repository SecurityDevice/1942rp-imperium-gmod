local PLUGIN = PLUGIN

PLUGIN.name = "Dragging"
PLUGIN.author = "Someone"
PLUGIN.desc = "Allows you to drag people."

nut.util.include("sv_hooks.lua")