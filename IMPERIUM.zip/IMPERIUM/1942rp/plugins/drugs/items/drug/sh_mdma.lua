ITEM.name = "MDMA"
ITEM.model = "models/props_junk/garbage_coffeemug001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "A popular street drug commonly known as ecstasy or molly, it was first developed by Merck in 1912."
ITEM.addictChance = 0 --no addictive properties
ITEM.effect = "drug_mdma" --the effect
ITEM.category = "Drugs"