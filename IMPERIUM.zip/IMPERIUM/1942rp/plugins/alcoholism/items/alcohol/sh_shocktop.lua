ITEM.base = "base_alcohol"
ITEM.name = "Alcohol"
ITEM.model = "models/props_junk/PopCan01a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.abv = 10
ITEM.desc = "This is an example alcohol item, containing %d%% ABV."