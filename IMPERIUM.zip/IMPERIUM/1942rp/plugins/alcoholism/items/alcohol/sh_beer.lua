﻿--------------------------------------------------------------------------------------------------------
ITEM.name = "Homemade Beer"
ITEM.desc = "Homemade Beer"
ITEM.model = "models/props_junk/garbage_glassbottle001a.mdl"
ITEM.uniqueID = "beer"
ITEM.width = 1
ITEM.height = 1
ITEM.abv = 13
ITEM.desc = "Has a 13 Percent ABV."
ITEM.sound = "eating_and_drinking/drinking.wav"
--------------------------------------------------------------------------------------------------------
