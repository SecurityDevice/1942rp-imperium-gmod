local PANEL = {}

local blindfolded = false
local dragging = false

function PANEL:Init()
    self:MakePopup()
    self:Center()
    self:ToggleVisible(false)
    local menu = DermaMenu()

    local blindplayer = menu:AddOption(blindfolded and "Remove Blindfold" or "Blindfold", function()
        LocalPlayer():ConCommand("say /blindplayer")
        self:Close()
        blindfolded = not blindfolded
    end)
    blindplayer:SetIcon(blindfolded and "icon16/user_gray.png" or "icon16/user_gray.png")

    local dragplayer = menu:AddOption(dragging and "Stop Dragging" or "Drag", function()
        LocalPlayer():ConCommand("say /dragplayer")
        self:Close()
        dragging = not dragging
    end)
    dragplayer:SetIcon(dragging and "icon16/link_break.png" or "icon16/link.png")

    local charsearch = menu:AddOption("Search Player", function()
        LocalPlayer():ConCommand("say /charsearch")
        self:Close()
    end)
    charsearch:SetIcon( "icon16/magnifier.png" )

    menu:Open()
    menu:MakePopup()
    menu:Center()
end

vgui.Register("cmenu_tying", PANEL, "DFrame")