local PANEL = {}

function PANEL:Init()
    self:MakePopup()
    self:Center()
    self:ToggleVisible(false)
    local menu = DermaMenu()

    local opentrunk = menu:AddOption("Open Trunk", function()
        LocalPlayer():ConCommand("say /trunk")
        self:Close()
    end)
    opentrunk:SetIcon( "icon16/box.png" )

    menu:Open()
    menu:MakePopup()
    menu:Center()
end

vgui.Register("cmenu_vehicle", PANEL, "DFrame")
