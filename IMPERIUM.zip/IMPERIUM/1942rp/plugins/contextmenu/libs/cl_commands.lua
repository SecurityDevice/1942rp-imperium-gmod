nut.command.add("requestsearch", {
    onRun = function(client, arguments) end
})

nut.command.add("tieplayer", {
    onRun = function(client, arguments) end
})

nut.command.add("cmenugivemoney", {
    onRun = function(client, arguments) end
})

nut.command.add("requestid", {
    onRun = function(client, arguments) end
})

nut.command.add("showid", {
    onRun = function(client, arguments) end
})
