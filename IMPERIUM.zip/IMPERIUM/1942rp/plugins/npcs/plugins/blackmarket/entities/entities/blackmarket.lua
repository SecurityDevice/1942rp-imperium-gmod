------------------------------------------------------------------------------------------
AddCSLuaFile()
------------------------------------------------------------------------------------------
local PLUGIN = PLUGIN
------------------------------------------------------------------------------------------
PLUGIN.Settings = PLUGIN.Settings or {}
------------------------------------------------------------------------------------------
ENT.Base = "leonheart_npc_base"
ENT.PrintName = "Black Market NPC"
ENT.Category = "Imperium Entities"
ENT.Author = "STEAM_0:1:176123778"
ENT.Model = PLUGIN.Settings.Model
ENT.NPCName = PLUGIN.Settings.Name
ENT.NPCDescription = PLUGIN.Settings.Description
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.NPCType = "blackmarket"
------------------------------------------------------------------------------------------