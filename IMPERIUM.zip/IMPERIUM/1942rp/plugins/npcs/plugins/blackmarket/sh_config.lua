------------------------------------------------------------------------------------------
local PLUGIN = PLUGIN
-------------------------------------------------------------------------------------------
PLUGIN.ImportableItemsCategories = {"Drugs & Weapons"}
-------------------------------------------------------------------------------------------
PLUGIN.ImportTime = 60
-------------------------------------------------------------------------------------------
PLUGIN.DropLocation = {
    ["Fanta Shop Basement"] = Vector(5822.910156, 6830.383301, -63.968750),
    ["Village"] = Vector(-8430.946289, 9134.607422, 124.031250),
    ["Behind OrPo"] = Vector(-629.210144, 1480.900391, 64.031250),
}

-------------------------------------------------------------------------------------------
PLUGIN.ImportableItems = {
    [FACTION_civy] = {
        ["Cocaine Brick"] = {
            item = "bulk_cocaine",
            price = 9500,
            category = "Drugs & Weapons",
        },
        ["M1911"] = {
            item = "m1911",
            price = 7000,
            category = "Drugs & Weapons",
        },
        ["M1 Garand"] = {
            item = "m1garand",
            price = 12000,
            category = "Drugs & Weapons",
        },
    },
}

-------------------------------------------------------------------------------------------
PLUGIN.Settings = {
    Name = "Smuggler",
    Model = "models/imperium/sssuits/gspcoat1.mdl",
    Profession = "Smuggler",
    Affiliation = "Smuggler",
    IntroductionText = "Hello. Are you in need of assistance?",
    Description = "",
    buttons = {
        ["I'd like to have something shipped in"] = {
            runhook = "OpenTraffickMenu",
            checkhook = nil,
        },
    },
}
-------------------------------------------------------------------------------------------