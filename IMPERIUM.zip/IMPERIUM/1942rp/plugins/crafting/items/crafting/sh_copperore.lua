ITEM.name = "Copper Ore"
ITEM.desc = "Ore mined from a copper node."
ITEM.price = 25
ITEM.model = "models/props_junk/rock001a.mdl"
ITEM.category = "Minerals"
ITEM.permit = "misc"
ITEM.maxstack = 5

ITEM.data = {
	Amount = 1
}