ITEM.name = "Wood Plank"
ITEM.desc = "Wood chopped from a tree."
ITEM.price = 25
ITEM.model = "models/props_debris/wood_chunk08e.mdl"
ITEM.category = "Other"
ITEM.permit = "misc"

ITEM.maxstack = 5

ITEM.data = {
	Amount = 1
}