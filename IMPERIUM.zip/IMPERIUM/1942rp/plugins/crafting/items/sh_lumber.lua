ITEM.name = "Lumber"
ITEM.desc = "A nice piece of lumber."
ITEM.price = 100
ITEM.model = "models/props_phx/construct/wood/wood_boardx1.mdl"
ITEM.category = "Refined"
ITEM.permit = "misc"