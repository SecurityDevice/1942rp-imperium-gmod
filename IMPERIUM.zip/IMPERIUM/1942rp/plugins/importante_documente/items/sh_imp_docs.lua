ITEM.name = "Important Documents"
ITEM.desc = "A piece of thick paper, quite fancy. Looks official. This document has something written on it."
ITEM.flag = "Y"
ITEM.model = "models/props_lab/clipboard.mdl"
ITEM.uniqueID = "papers"
ITEM.netUID = "openUpID"
ITEM.additionalArg = nil

ITEM.noDrop = true

ITEM.functions.show = {
  icon = "icon16/user.png",
  name = "Show",
  onRun = function(item)
    local ply = item.player
  if (ply.NextDocumentCheck && ply.NextDocumentCheck > SysTime()) then ply:notify("You can't show documents that quickly!") return false end
  ply.NextDocumentCheck = SysTime() + 5
    local target = ply:GetEyeTrace().Entity
    if not target:IsPlayer() or not IsValid(target) or target:GetPos():Distance(ply:GetPos()) > 500 then return end

    netstream.Start(target, "openUpID", ply)
    return false
  end,
  onCanRun = function(item)
    local trEnt = item.player:GetEyeTrace().Entity
    return IsValid(trEnt) and trEnt:IsPlayer()
  end
}

ITEM.functions.showself = {
  icon = "icon16/brick.png",
  name = "View",
  onRun = function(item)
      local ply = item.player

      if (ply.NextDocumentCheck and ply.NextDocumentCheck > SysTime()) then
          ply:notify("You can't view documents that quickly!")

          return false
      end

      ply.NextDocumentCheck = SysTime() + 5
      netstream.Start(ply, item.netUID, ply, item.additionalArg)

      return false
  end,
}

function ITEM:onCanBeTransfered(oldInventory, newInventory)
  return false
end